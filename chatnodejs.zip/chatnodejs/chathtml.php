
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>All Exam Info</title>
        <!-- Bootstrap -->
        <link href="<?php echo Yii::app()->request->baseUrl; ?>/esscitheme/onlineassessment/css/bootstrap.min.css" rel="stylesheet">
        <!-- Bootstrap -->
        <!-- Custome CSS Start-->
        <link rel="shortcut icon" type="image/png" href="images/fav.png"/>
        <link href="<?php echo Yii::app()->request->baseUrl; ?>/esscitheme/onlineassessment/css/style.css" rel="stylesheet">
        <link href="<?php echo Yii::app()->request->baseUrl; ?>/esscitheme/onlineassessment/css/responsive.css" rel="stylesheet">
        <!-- Custome CSS END-->
        <!-- Font Awesome CSS Start-->
        <link href="<?php echo Yii::app()->request->baseUrl; ?>/esscitheme/onlineassessment/css/font-awesome.min.css" rel="stylesheet">
        <link href="<?php echo Yii::app()->request->baseUrl; ?>/esscitheme/onlineassessment/css/countdown/jquery.countdown.css" rel="stylesheet">

        <script src="<?php echo Yii::app()->request->baseUrl; ?>/esscitheme/onlineassessment/js/jquery.min.js"></script>
		<script src="<?php echo Yii::app()->request->baseUrl; ?>/esscitheme/onlineassessment/js/RecordRTC.js"></script>
    
    <!-- web streams API polyfill to support Firefox -->
    <script src="https://unpkg.com/@mattiasbuelens/web-streams-polyfill/dist/polyfill.min.js"></script>

    <!-- ../libs/DBML.js to fix video seeking issues -->
    <script src="https://www.webrtc-experiment.com/EBML.js"></script>

    <!-- for Edge/FF/Chrome/Opera/etc. getUserMedia support -->
    <script src="https://webrtc.github.io/adapter/adapter-latest.js"></script>
    <script src="https://www.webrtc-experiment.com/DetectRTC.js"> </script>

    <!-- video element -->
    <link href="https://www.webrtc-experiment.com/getHTMLMediaElement.css" rel="stylesheet">
    <script src="https://www.webrtc-experiment.com/getHTMLMediaElement.js"></script>
        <style>
            .justify{
                text-align: justify;
            }
            .submit_assessment{
            }
            .overlay-exam{
                background-color: rgba(0,0,0,0.6);
             position: absolute;
                top: 0;
                left: 0;
                right:0;
                bottom: 0;
            }
            .margin-bottom-15{
                margin: 5px -7px 8px 5px;
            }
            .candi-info{
                border: none;
                color: #2ea879;
                font-weight: 600;
            }
            .btn-info{
                color: #fff;
                background-color: #2ea879;
                border-color: #2ea879;
                border-radius: 0px;
            }
            .panel-group {
                margin-bottom: 0px;
            }
            .panel-body {
                padding: 0px;
            }
            .container-instruction{
                background: #fff;
                color:#000;
                width:80%;
                margin: 0 auto;
                border-radius: 20px;
                padding:30px 20px;
                position: absolute;
                top: 50%;
                left: 50%;
                -moz-transform: translateX(-50%) translateY(-50%);
                -webkit-transform: translateX(-50%) translateY(-50%);
                transform: translateX(-50%) translateY(-50%);
            }
            .container-instruction h1{
                text-align: center;
            }
            .container-instruction ol li {
                font-size:16px;
            }
            .container-instruction button {
                background: #666;
                color: #fff;
                padding:3px 10px;
                border: none;
                font-size: 20px;
                border-radius:2px;
            }
        </style>
        
        <style>
            .color-red{
                color:#ed1c24;
            }
            .color-green{
                color:#4CAF50;
            }
            #element {
				background-color: #e9e9e9;	
			}
			.questions-cols-ans{
			    overflow-y: scroll;
			    float: left;
			    width: 100%;
			    max-height:325px;
			}
			.profile-head {
			    float: left !important;
			}
			.exam-card {
			    margin-bottom: 10px !important;
			}
			
/*-------chat window css-----*/
.panel{
    margin-bottom: 0px;
}
.chat-window{
    bottom:0;
	    left: 0px;
    position:fixed;
    float:right;
}
.chat-window > div > .panel{
    border-radius: 5px 5px 0 0;
}
.get_msg{
	width:100% !important;
}
.icon_minim{
    padding:2px 10px;
}
.msg_container_base{
  background: #e5e5e5;
  margin: 0;
  padding: 0 10px 10px;
  max-height:150px;
  /*width: 430px;*/
  overflow-x:hidden;
}
.top-bar {
  background: #666;
  color: white;
  padding: 10px;
  position: relative;
  overflow: hidden;
}
.msg_receive{
    padding-left:0;
    margin-left:0;
}
.msg_sent{
    padding-bottom:20px !important;
    margin-right:0;
}
.messages {
  background: white;
  padding: 10px;
  border-radius: 2px;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
  max-width:100%;
  margin: 3px;
}
.messages > p {
    font-size: 13px;
    margin: 0 0 0.2rem 0;
  }
.messages > time {
    font-size: 11px;
    color: #ccc;
}
.msg_container {
    padding: 10px;
    overflow: hidden;
    display: flex;
}

img {
    display: block;
    width: 100%;
}

.avatar {
    position: relative;
}
.base_receive > .avatar:after {
    content: "";
    position: absolute;
    top: 0;
    right: 0;
    width: 0;
    height: 0;
    border: 5px solid #FFF;
    border-left-color: rgba(0, 0, 0, 0);
    border-bottom-color: rgba(0, 0, 0, 0);
}

.base_sent > .avatar:after {
    content: "";
    position: absolute;
    bottom: 0;
    left: 0;
    width: 0;
    height: 0;
    border: 5px solid white;
    border-right-color: transparent;
    border-top-color: transparent;
    box-shadow: 1px 1px 2px rgba(black, 0.2); // not quite perfect but close
}

.msg_sent > time{
    float: right;
}

.msg_container_base::-webkit-scrollbar-track{
    -webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.3);
    background-color: #F5F5F5;
}

.msg_container_base::-webkit-scrollbar{
    width: 12px;
    background-color: #F5F5F5;
}

.msg_container_base::-webkit-scrollbar-thumb{
    -webkit-box-shadow: inset 0 0 6px rgba(0,0,0,.3);
    background-color: #555;
}

.btn-group.dropup{
    position:fixed;
    left:0px;
    bottom:0;
}
.proctor{
	background: #d9534f;
}
.proctor P {
    color: #fff !important;
    font-weight: 700;
}
        </style>

        <script>
            $(function () {
                setInterval(function () {
                    $('.fa-circle').toggleClass('color-red').toggleClass('color-green')
                }, 500);
            });
            //document.addEventListener('contextmenu', event => event.preventDefault());
        </script>
    </head>
    <body id="exams-tests1" class="my-body-bg">

<?php
    if($getCandidateArray[0]['online_theory_assessment_status'] != 'C') {
?>
    <div id="element">
        <div class="row">
         <div class="col-md-12">
         
        	<div class="col-md-8">
             <div class="row" id="t1" style="display: none;">
                <header class="exam-header-new">
                    <div class="row">

                        <div class="col-md-4 col-sm-12 col-xs-12 exam-test-cols1 clearfix" >
                            <span style="border:1px solid #000; margin-left:10px;padding:3px 10px; z-index:999999; background-color:#ededed; border-radius:13px; font-size: 15px;"><i class="fa fa-circle color-red" style=""></i> Live</span> <button class="btn btn-default hidden" onclick="GoInFullscreen(element);">Full Screen </button>
                        </div>
                        
                        <div class="col-md-4 col-sm-6 col-xs-6 exam-test-cols1 clearfix count-timer">
                            <a href="#" class="test-header">
                                <div class="left-div">
                                    <i class="fa fa-2x fa-clock-o left-arrow-icon" aria-hidden="true"></i>
                                </div>
                                <div class="right-div">
                                    <h3><div id="countdown"></div></h3>

                                </div>
                            </a>
                        </div>	
                        <div class="col-md-4 col-sm-4 col-xs-6 exam-test-cols2 clearfix submit-assessment-top-button"> 
                            <a href="#"><button type="button" class="btn btn-default pull-right submit_assessment" id="submitas" style="background: #ff0000;">Submit Assessment</button></a>
                             	</div>	
							 <section class="experiment recordrtc" style="display:none">
            <h2 class="header" style="margin: 0;">
                <select class="recording-media" style="display:none">
                 
                    <option value="record-audio-plus-screen">Microphone+Screen</option>
                </select>

                <span style="font-size: 15px;">into</span>

                <select class="media-container-format" style="display:none">
                    <option>default</option>
                 
                </select>

                <input type="checkbox" id="chk-timeSlice" style="margin:0;width:auto;" title="Use intervals based recording">
                <label for="chk-timeSlice" style="font-size: 15px;margin:0;width: auto;cursor: pointer;-webkit-user-select:none;user-select:none;" title="Use intervals based recording">Use timeSlice?</label>

                <br>

                <button id="btn-start-recording">Start Recording</button>
                <button id="btn-pause-recording" style="display: none; font-size: 15px;">Pause</button>

                <div style="display: none;">
                    <input type="checkbox" id="chk-fixSeeking" style="margin:0;width:auto;" title="Fix video seeking issues?">
                    <label for="chk-fixSeeking" style="font-size: 15px;margin:0;width: auto;cursor: pointer;-webkit-user-select:none;user-select:none;" title="Fix video seeking issues?">Fix Seeking Issues?</label>
                </div>

              
                <select class="media-resolutions" style="display:none">
                    <option value="default">Default resolutions</option>
                  
                </select>

                <select class="media-framerates" style="display:none">
                    <option value="default">Default framerates</option>
                  
                </select>

                <select class="media-bitrates" style="display:none">
                    <option value="default">Default bitrates</option>
                 
                </select>
            </h2>

           <!-- <div style="text-align: center; display: none;">
                <button id="save-to-disk">Save To Disk</button>
              
            </div>-->

            <div style="margin-top: 10px;" id="recording-player"></div>
        </section>
		
                <button id="save-to-disk" class="btn btn-success"  style="display:none">Save To Disk</button>
              
             <button id="upload-to-php" class="btn btn-success uphp"  style="display:none" >Upload to PHP</button>

										
                    </div>

                </header>
             </div>
             
             <div class="row" id="t2" style="display: none;">
                <div class="main-page-test" style="margin-top: 25px;">
                    <div class="row">

                        <div class="col-md-9 col-sm-12 col-xs-12 exam-tests-column-left">
                            <style>

                            </style>
                            <div class="exam-card profile">
                                <div class="row">
                                    <div class="profile-head">
                                        <div class="profiles">
                                            <div class="col-md-2 col-sm-3 col-xs-5">
                                                <div class="row" style="margin-right:0; margin-left:0;">
                                                    <img src="<?php echo Yii::app()->request->baseUrl; ?>/upload/candidates/<?php echo $getCandidateArray[0]['candidate_photo']; ?>" class="img-responsive"/>

                                                </div>
                                            </div>
                                            <div class="col-md-9 col-sm-8 col-xs-9">
                                                <div class="row">


                                                    <div class="col-md-12 col-sm-6 col-xs-6">
                                                        <p><span class="candi-info">Candidate ID : </span> <span id="candidate-id"><?php echo $candidateId; ?></span></p>

                                                        <input type="hidden" id="paper-id" value="<?php echo $paper_id; ?>">
                                                        <input type="hidden" id="batch-id" value="<?php echo $batch_id; ?>">

                                                        <p><span class="candi-info">Candidate Name : </span><?php echo $getCandidateArray[0]['candidate_name']; ?></p>
                                                        <p><span class="candi-info">Job Role : </span> <?php echo $getjobrole; ?> (<?php echo $getqpcode; ?>)</p>
                                                    </div>


                                                </div>
                                            </div>

                                        </div>
                                    </div><!--profile-head close-->
                                </div>
                            </div>

                            <!-- start Slider -->
                            <div class="exam-card">
                                <ul class="nav nav-tabs" id="exam-test-tabs" role="tablist">
                                    <li role="presentation" class="active"><a href="#quantitative" aria-controls="quantitative" role="tab" data-toggle="tab">Online Assessment Questions</a></li>

                                </ul>
                                <!-- Top part of the slider -->

                                <div class="span8" id="carousel-bounding-box">
                                    <div class="carousel slide" id="myCarousel">
                                        <!-- Carousel items -->
                                        <div class="carousel-inner">
                                            <?php
                                            $c = 1;
                                            foreach ($getAssessmentQuestions As $keyValue => $getAssessmentQuestionsSet) {
                                            ?>
                                                <tr>
                                                    <?php
                                                    $key = 0;
                                                    $question = 0;
                                                    
                                                    //$ct = count($getAssessmentQuestionsSet);
                                                     
                                                    foreach ($getAssessmentQuestionsSet As $key => $value) {
                                                    	
                                                     //$t = rand(0,($ct-1));
                                                    	
                                                    ?>
                                                    <div class="item mydivs qpcodelinker" data-slide-number="<?php echo $c; ?>">
                                                        <!-- Question Area-->

                                                        <div class="row">	
                                                            <div class="col-md-12 col-sm-12 col-xs-12 test-cols-bgcolor">
                                                                <div class="questions-cols-border">
                                                                    <div class="row">
                                                                        <div class="col-md-12 col-sm-12 col-xs-12">
                                                                            <div class="question-badges-left">
                                                                                <span class="badge question_id" data-question-id="<?php echo $value['question_id']; ?>"> Question <?php echo $c; ?></span>
                                                                                |
                                                                                <span class="badge"> <?php echo $value['nos_code']; ?></span><span class="badge pull-right badge_marks">marks <?php echo $value['question_marks']; ?></span>
                                                                            </div>
                                                                        </div>
                                                                        <!-- <div class="qpcodecontainer float-left">
                                                                                <p></p>
                                                                        </div> -->
                                                                        <div class="col-md-12 col-sm-12 col-xs-12 test-questions">
                                                                            <h4><?php echo $value['question']; ?><br><br>(<?php echo $value['hindi_question']; ?>)</h4>
                                                                            <?php
                                                                            if ($value['question_image'] == NULL) {
                                                                                
                                                                            } else {
                                                                                ?>
                                                                                <br>
                                                                                <center><img src="<?php echo Yii::app()->request->baseUrl; ?>/upload/question_images/<?php echo $value['question_image']; ?>" alt="" class="img-fluid"></center>
                                                                                <?php
                                                                            }
                                                                            ?>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                 <div class="questions-cols-ans">

                                                                    <div class="col-md-12 col-sm-12 col-xs-12">
                                                                        <h4 class="answers">Answers:</h4>
                                                                    </div>
                                                                    <div class="col-md-12 col-sm-12 col-xs-12 ans-questions">
                                                                        <div class="funkyradio">
                                                                            
                                                                            
                                                                            
                                                                              <?php if($value['option1'] != "" || $value['option1_image'] != "" ){ ?>
                                                                            <div class="funkyradio-warning">
                                                                                <input type="radio" name="<?php echo $getqpcode; ?>_<?php echo $c; ?>_radio" id="<?php echo $getqpcode; ?>_<?php echo $c; ?>_radio1" data-qpcode="<?php echo $getqpcode; ?>_<?php echo $c; ?>" value="<?php echo $getqpcode; ?>_<?php echo $c; ?>_1" class="getClickAnswer" />



                                                                                <label for="<?php echo $getqpcode; ?>_<?php echo $c; ?>_radio1">
                                                                                    <?php
                                                                                    if ($value['option1'] != NULL && $value['option1'] != "") {
                                                                                        echo $value['option1'];
                                                                                        ?> <?php
                                                                                        echo "(".$value['hindi_option1'].")";
                                                                                    } else {
                                                                                        ?>
                                                                                        <center><img src="<?php echo Yii::app()->request->baseUrl; ?>/upload/question_option_images/<?php echo $value['option1_image']; ?>" alt="" class="img-fluid"></center>
																					<?php } ?>   

                                                                                </label>
                                                                            </div>
                                                                            <?php } ?>
                                                                            
                                                                            <?php if($value['option2'] != "" || $value['option2_image'] != "" ){ ?>
                                                                            <div class="funkyradio-warning">
                                                                                <input type="radio" name="<?php echo $getqpcode; ?>_<?php echo $c; ?>_radio" id="<?php echo $getqpcode; ?>_<?php echo $c; ?>_radio2" data-qpcode="<?php echo $getqpcode; ?>_<?php echo $c; ?>" value="<?php echo $getqpcode; ?>_<?php echo $c; ?>_2" class="getClickAnswer"/>
                                                                                <label for="<?php echo $getqpcode; ?>_<?php echo $c; ?>_radio2">                      <?php
                                                                                    if ($value['option2'] != NULL && $value['option2'] != "") {
                                                                                        echo $value['option2'];
                                                                                        ?> <?php
                                                                                        echo "(".$value['hindi_option2'].")";
                                                                                    } else {
                                                                                        ?>
                                                                                        <center><img src="<?php echo Yii::app()->request->baseUrl; ?>/upload/question_option_images/<?php echo $value['option2_image']; ?>" alt="" class="img-fluid"></center>
            <?php } ?>   </label>
                                                                            </div>
                                                                            
                                                                            <?php } ?>
                                                                            
                                                                            <?php if($value['option3'] != "" || $value['option3_image'] != "" ){ ?>
                                                                            <div class="funkyradio-warning">
                                                                                <input type="radio" name="<?php echo $getqpcode; ?>_<?php echo $c; ?>_radio" id="<?php echo $getqpcode; ?>_<?php echo $c; ?>_radio3" data-qpcode="<?php echo $getqpcode; ?>_<?php echo $c; ?>" value="<?php echo $getqpcode; ?>_<?php echo $c; ?>_3" class="getClickAnswer" />
                                                                                <label for="<?php echo $getqpcode; ?>_<?php echo $c; ?>_radio3">                      <?php
                                                                                    if ($value['option3'] != NULL && $value['option3'] != "") {
                                                                                        echo $value['option3'];
                                                                                        ?> <?php
                                                                                        echo "(".$value['hindi_option3'].")";
                                                                                    } else {
                                                                                        ?>
                                                                                        <center><img src="<?php echo Yii::app()->request->baseUrl; ?>/upload/question_option_images/<?php echo $value['option3_image']; ?>" alt="" class="img-fluid"></center>
            <?php } ?>   </label>
                                                                            </div>
                                                                            
                                                                            <?php } ?>
                                                                            <?php if($value['option4'] != "" || $value['option4_image'] != "" ){ ?>
                                                                            <div class="funkyradio-warning">
                                                                                <input type="radio" name="<?php echo $getqpcode; ?>_<?php echo $c; ?>_radio" id="<?php echo $getqpcode; ?>_<?php echo $c; ?>_radio4" data-qpcode="<?php echo $getqpcode; ?>_<?php echo $c; ?>" value="<?php echo $getqpcode; ?>_<?php echo $c; ?>_4" class="getClickAnswer"/>
                                                                                <label for="<?php echo $getqpcode; ?>_<?php echo $c; ?>_radio4">                      <?php
                                                                                    if ($value['option4'] != NULL && $value['option4'] != "") {
                                                                                        echo $value['option4'];
                                                                                        ?> <?php
                                                                                        echo "(".$value['hindi_option4'].")";
                                                                                    } else {
                                                                                        ?>
                                                                                        <center><img src="<?php echo Yii::app()->request->baseUrl; ?>/upload/question_option_images/<?php echo $value['option4_image']; ?>" alt="" class="img-fluid"></center>
            <?php } ?>   </label>
                                                                            </div>
                                                                            
                                                                            <?php } ?>
                                                                            
                                                                            
                                                                            

                                                                        </div>
                                                                        <a class="btn btn-info previous left" href="javascript:void(0);" data-getqpcode="<?php echo $getqpcode; ?>_<?php echo $c; ?>">‹ Previous </a> 
<!-- href="#myCarousel" data-slide="prev" --> 
                                                                        <button type="button" class="btn btn-default  footer-test-btns clearsection" data-getid="<?php echo $c; ?>" data-getqpcode="<?php echo $getqpcode; ?>_<?php echo $c; ?>"><i class="fa fa-times-circle" aria-hidden="true"></i> Clear Section</button>
                                                                        
                                                                        <a class="btn btn-info pull-right next right" href="javascript:void(0);" data-getqpcode="<?php echo $getqpcode; ?>_<?php echo $c; ?>">Next ›</a>
<!-- href="#myCarousel" data-slide="next" -->
                                                                        <br><br>
                                                                    </div>										

                                                                </div>	

                                                            </div>

                                                        </div>


                                                    </div>


                                                    <?php
                                                    ++$c;
                                                }
                                            }
                                            ++$c;
                                            ?>     




                                        </div><!-- Carousel nav -->
                                    </div>
                                    
                                    <span id="myCarousel_msg"></span>
                                </div>

                                <!--end slider-->
                                <!-- Tab panes -->

                            </div>

                        </div>

                        <div class="col-md-3 col-sm-12 col-xs-12 exam-tests-column-right" id="QuestionArea">
                            <div class="main-ans-div">
                                <div class="table-scrollar-text">
                                    <div class="panel-group" id="accordion">
                                        <div class="panel panel-default active">
                                            <div class="panel-heading">
                                                <h4 class="test-panel-title">
                                                    <a data-toggle="collapse" data-parent="#accordion" href="#collapseOne">
                                                        <i class="fa fa-caret-right"></i> No. of Questions (<span class="candi-info" id="total-questions"><?php echo $countTotalQuestion; ?></span>)
                                                    </a>
                                                </h4>
                                            </div>
                                            <style>
                                                .scroll-div-11{
                                                    overflow-y: scroll;
                                                    max-height: 368px !important;
                                                    min-height: 368px !important;

                                                }

                                                .nosclass{
                                                    font-weight: 600;
                                                    font-size: 15px;
                                                    margin-bottom: 15px;
                                                    background: #2ea879;
                                                    padding: 5px;
                                                    color: #fff;

                                                    text-align: center;
                                                }                                        

                                            </style>
                                            <div id="collapseOne" class="panel-collapse collapse in">
                                                <div class="panel-body">
                                                    <div class="scroll-div-11">
                                                        <div class="row" style="margin-right:0px; margin-left: 0px;">
                                                            <?php
                                                            //print_r($Rarr);
                                                            $c = 1; //$i=0;
                                                            foreach ($nosCodeArray As $keyValue => $getAssessmentQuestions) {
                                                            ?>

                                                                <?php echo "<h5 class='nosclass'>" . $keyValue . "</h5>"; ?>

                                                                <?php
                                                                
                                                                $key = 0;
                                                                $question = 0;
                                                                
                                                                $ct = count($getAssessmentQuestions);
                                                                
                                                                foreach($getAssessmentQuestions As $key => $value) {
                                                                   //$t = rand(0,($ct-1));
                                                                 
                                                                ?>
                                                                    <div class="col-md-3 col-sm-3 col-xs-3 margin-bottom-15">
                                                                        <a id="mydata_<?php echo $value['paper_qpcode']; ?>_<?php echo $c; ?>" class="test-questions-ans-wrong gray sidequestionbar" data-id="<?php echo $c; ?>" data-qpcode="<?php echo $getqpcode; ?>" ><?php echo $c; ?></a>

                                                                    </div>
                                                                    <?php
                                                                    ++$c; //$i++;
                                                                }
                                                                ?>
                                                                <div class="clearfix"></div>
                                                                <?php
                                                            }
                                                            ++$c; 
                                                            ?>


                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <script>
                                        (function () {
                                            $(".panel").on("show.bs.collapse hide.bs.collapse", function (e) {
                                                if (e.type == 'show') {
                                                    $(this).addClass('active');
                                                } else {
                                                    $(this).removeClass('active');
                                                }
                                            });
                                        }).call(this);
                                    </script>


                                    <div class="test-sign-icons">
                                        <div class="div-responsive">
                                            <table class="table" id="test-signs">
                                                <tbody>
                                                    <tr>
                                                        <td><span class="test-questions-ans-icons-gray" id="getNotVisited">0</span><br> <span class="test-fonts">Not Visited</span></td>
                                                        <td><span class="test-questions-ans-icons-red" id="getNotAnswered">0</span> <br><span class="test-fonts">Not Answered</span></td>
                                                        <td><span class="test-questions-ans-icons-blue" id="getAnswered">0</span> <br><span class="test-fonts">Answered</span></td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>						

                                    <ul class="list-inline test-ans-menu" style="margin-bottom:0; padding-left:10px;">
                                        <li class="instruction_modal_open"><a href="#">Instructions</a></li>
                                    </ul>
                                  
                                    
                                    <ol class="instruction_toggle"  style="display:none; padding-left:30px; padding-bottom:10px; font-size:12px;">
                                    <li>All Questions are Mandatory.</li>
                <li>There is no negative marking.</li>
                <li>Maximum time duration (in hours).</li>
                <li>Hold the device properly.</li>
                <li>Face should be visible in camera.</li>
                <li>Alternative language options are available.</li>
                                    </ol>
                                    
                                </div>
                            </div>
                        </div>	
                    </div>
                </div>
                <style>
                    .bottom-div{
                position:fixed;
                bottom:0;
                right:0;
                left:0;
                background-color: #D9DEE4;
                display: none;
            }
                  
               /* Media Query for low resolution  Tablets, Ipads */ 
       @media (max-width: 768px) { 
             .bottom-div button{
             font-weight:600;
             color:#000;
            }
            #start-exam{
                position: absolute;
                top:0px;
            }
             .container-instruction{
                background: #fff;
                color:#000;
                width:80%;
                margin: 0 auto;
                border-radius: 20px;
                padding:20px 20px 30px 0px; 
                position: absolute;
                top: 50%;
                left: 50%;
                -moz-transform: translateX(-50%) translateY(-60%);
                -webkit-transform: translateX(-50%) translateY(-60%);
                transform: translateX(-50%) translateY(-60%);
            }
              .container-instruction h1{
                text-align: center;
                font-size: 16px;
            }
            .container-instruction ol li {
                 font-size: 12px;
            }
            .container-instruction button {
                background: #666;
                color: #fff;
                padding:3px 10px;
                border: none;
                font-size: 15px;
                border-radius:2px;
            }
            .exam-card h4, label{
                font-size: 12px;
            }
            .container-instruction{
                font-size: 100px !important;
            }
            .clearsection{
                position: absolute;
                bottom: 20px;
                height:34px;
                left:110px;
                 
            }
            .badge_marks{
                position: absolute;
                right:-70px;
            }
             .bottom-div button a{
            
             text-decoration: none;
            }
              .bottom-div button a:hover{
                   color:white;
               text-decoration: none;
            }
               
                       .bottom-div{
              
                display: block;
            }
            .question-badges-left{
            position: relative;
            right:95px;
            }
            .submit-assessment-top-button{
              display:none;  
            }
            .profile{
                display: none;
            }
              #QuestionArea{
                  display: none;
                  position:absolute;
                  top:0;
                  bottom:0;
                  right:0;
                  left:0;
                  background-color:white;
                  z-index:9999;

                }
                .count-timer{
                    position: absolute;
                    right: 0;
                    
                }
        } 
                </style>
                
                <div class="bottom-div">
                    <div class="row" style="margin-right:0; margin-left:0;">
                        <div class="col-xs-4 no-padding">
                           <button type="button" class="btn btn-link form-control" id="myProfileButton" data-toggle="modal" data-target="#ProfileModel">My Profile</button>
                        </div>
                          <div class="col-xs-4 no-padding">
                               <button type="button" class="btn btn-link  form-control" id="myQuestionButton">All Question</button>
                        </div>
                        <div class="col-xs-4 no-padding" style="background:#ed2c01;">
                            <a href="#"><button type="button" class="btn btn-link  submit_assessment  form-control" style="color:#fff;">Submit</button></a>
                        </div>
                    </div>
                    
                </div>
             </div>
             
             
             <div class="row" id="t3" style="display: block;">
                <header>
                    <div class="row">
                       <div class="col-md-12 col-sm-12 col-xs-12 exam-test-cols1 clearfix" >
				            <h1>Read Instructions Before Starting the Exam</h1>
				            <ol class="justify text-center">
				                <li>All Questions are mandatory.</li>
				                <li>There is no negative marking.</li>
				                <li>Maximum time duration is mentioned on the top.</li>
				                <li>Hold the device properly.</li>
				                <li>Alternative language option are available.</li> 
				                <li>Please do not refresh the page and do not move to back window</li> 
				            </ol>
				        </div>						
                    </div>
                </header>
             </div>
            
             <div class="row" id="t4" style="display: none;">
                <header>
                    <div class="row">
                       <div class="col-md-12 col-sm-12 col-xs-12 exam-test-cols1 clearfix" >  
				            <h1>Please wait. Your screen is going to share</h1>
				            <ol class="justify text-center">
				                <li>Step to share your screen</li>
				                <li>A window is opened automatically.</li>
				                <li>Select "Your Entire Screen" tab.</li>
				                <li>Click to share button.</li>
				                <li>After clicking on "share" button. Please do not refresh the page and do not move to back window</li>  
				            </ol>
				        </div>						
                    </div>
                </header>
             </div>
           
          </div><!-- col-md-8 --> 
          
         <div class="col-md-4">
      		<div class="col-md-12 alert alert-info">
			 <center>	
				<input type="hidden" id="room-id" value="<?php echo $candidateId;?>" autocorrect=off autocapitalize=off size=20>
		    	<button id="open-room" style="display:none;">Share Screen</button>
		    	<button id="join-room" style="display:none;">Join Room</button>
		    	<button id="open-or-join-room" style="display:none;">Auto Open Or Join Room</button>
		    	<div id="videos-container"></div>
		    	<div id="room-urls" style="text-align: center;display:none;background: #F1EDED;border: 1px solid rgb(189, 189, 189);"></div>							
			    	
				<button id="grabFrame" style="display:none;">Grab Frame</button>
	            <button id="takePhoto" style="display:none;">Take Photo</button>
	            <div class="select" class="hidden">
	                <select id="videoSource" class="hidden"></select>
	            </div>
	            <input class="hidden" id="zoom" type="range" step="20">
	            <input type="hidden" id="image-tag">
	            <img>
	            <canvas width="460" height="370"></canvas>
				<video autoplay class="hidden" id="video"></video>
			 </center>	
			 <div class="text-danger">
			   <center id="focusmsg"><strong>Note:- </strong> Please maintain focus of camera on your face</center>
			   <center><strong class="getMsgError">&nbsp;</strong></center>
			 </div>	
		   </div>
		   
		   
		    <div class="col-xs-12 col-md-12 alert alert-info" id="chat_window_1" style="display:none;">
			    <div class="panel-body msg_container_base">
                    <div class="row msg_container base_sent">
                        <div class="col-md-10 col-xs-10 get_msg">
                        	<div class="messages msg_sent proctor"></div>
                        </div>
                    </div>
                </div>
                
                <div class="panel-footer" style="display:block;">
					<div class="input-group">
						<input id="btn-input" class="form-control sendie" type="text"  class="form-control input-sm chat_input" placeholder="Write your message here..." />
						<span class="input-group-btn">
						    <button class="btn btn-primary btn-sm btn-enter-chat" id="btn-chat">Send</button>
						</span>
					</div>
				</div>	
			</div>
		   
		    <div class="col-xs-12 col-md-12 alert alert-info">
			    <div class="panel-body msg_container_base">
                    <div id="otEmbedContainer" style="width=100%; height:400px; display:none;"></div> 
                   <script src="https://tokbox.com/embed/embed/ot-embed.js?embedId=28b73018-5c24-40b2-8ff6-15b2737f9fab&room=<?php echo $candidateId;?>"></script>
                </div>	
			</div>
          
          </div><!-- col-md-4 --> 
          
     </div><!-- col-md-12 -->	   	
    </div><!-- row -->

<script>
    var videoId = 'video';
    var scaleFactor = 1;
    var snapshots = [];
    function capture(video, scaleFactor) {
        if (scaleFactor == null) {
            scaleFactor = 1;
        }
        var w = video.videoWidth * scaleFactor;
        var h = video.videoHeight * scaleFactor;
       
        var canvas = document.createElement('canvas');
        canvas.width = w;
        canvas.height = h;
        var ctx = canvas.getContext('2d');
        ctx.drawImage(video, 0, 0, w, h);
        return canvas;
    }
</script>
</script>

<script>
    function startWebcam() {
        'use strict';
        var isSecureOrigin = location.protocol === 'https:' ||
        location.host === 'localhost';
        if (!isSecureOrigin) {
            alert('getUserMedia() must be run from a secure origin: HTTPS or localhost.' +
                    '\n\nChanging protocol to HTTPS');
            location.protocol = 'HTTPS';
        }

        var constraints;
        var imageCapture;
        var mediaStream;

        var grabFrameButton = document.querySelector('button#grabFrame');
        var takePhotoButton = document.querySelector('button#takePhoto');

        var canvas = document.querySelector('canvas');
        var img = document.querySelector('img');
        var video = document.querySelector('video');
        var videoSelect = document.querySelector('select#videoSource');
        var zoomInput = document.querySelector('input#zoom');

        grabFrameButton.onclick = grabFrame;
        takePhotoButton.onclick = takePhoto;
        videoSelect.onchange = getStream;
        zoomInput.oninput = setZoom;

        navigator.mediaDevices.enumerateDevices()
                .then(gotDevices)
                .catch(error => {
                    console.log('enumerateDevices() error: ', error);
                })
                .then(getStream);

        function gotDevices(deviceInfos) {
            for (var i = 0; i !== deviceInfos.length; ++i) {
                var deviceInfo = deviceInfos[i];
                console.log('Found media input or output device: ', deviceInfo);
                var option = document.createElement('option');
                option.value = deviceInfo.deviceId;
                if (deviceInfo.kind === 'videoinput') {
                    option.text = deviceInfo.label || 'Camera ' + (videoSelect.length + 1);
                    videoSelect.appendChild(option);
                }
            }
        }

        function getStream() {
            if (mediaStream) {
                mediaStream.getTracks().forEach(track => {
                    track.stop();
                });
            }
            var videoSource = videoSelect.value;
            constraints = {
                video: {deviceId: videoSource ? {exact: videoSource} : undefined}
            };
            navigator.mediaDevices.getUserMedia(constraints)
                    .then(gotStream)
                    .catch(error => {
                        console.log('getUserMedia error: ', error);
                    });
        }

        function gotStream(stream) {
            console.log('getUserMedia() got stream: ', stream);
            mediaStream = stream;
            video.srcObject = stream;
            /*video.classList.remove('hidden');*/
            imageCapture = new ImageCapture(stream.getVideoTracks()[0]);
            getCapabilities();
        }

        function getCapabilities() {
            imageCapture.getPhotoCapabilities().then(function (capabilities) {
                console.log('Camera capabilities:', capabilities);
                if (capabilities.zoom.max > 0) {
                    zoomInput.min = capabilities.zoom.min;
                    zoomInput.max = capabilities.zoom.max;
                    zoomInput.value = capabilities.zoom.current;
                    zoomInput.classList.remove('hidden');
                }
            }).catch(function (error) {
                console.log('getCapabilities() error: ', error);
            });
        }

        function grabFrame() {
            imageCapture.grabFrame().then(function (imageBitmap) {
                console.log('Grabbed frame:', imageBitmap);
                canvas.width = imageBitmap.width;
                canvas.height = imageBitmap.height;
                canvas.getContext('2d').drawImage(imageBitmap, 0, 0);
                canvas.classList.remove('hidden');
            }).catch(function (error) {
                console.log('grabFrame() error: ', error);
            });
        }

        function setZoom() {
            imageCapture.setOptions({
                zoom: zoomInput.value
            });
        }
        
        /*function takePhoto() {
            imageCapture.takePhoto().then(function (blob) {
                console.log('Took photo:', blob);
                img.classList.remove('hidden');
                img.src = URL.createObjectURL(blob);
            }).catch(function (error) {
                console.log('takePhoto() error: ', error);
            });
        }*/
    }
    startWebcam();
</script>   

<script src="https://kaushalganga.herokuapp.com/dist/RTCMultiConnection.js"></script>
<script src="https://kaushalganga.herokuapp.com/node_modules/webrtc-adapter/out/adapter.js"></script>
<script src="https://kaushalganga.herokuapp.com/socket.io/socket.io.js"></script>

<!-- custom layout for HTML5 audio/video elements -->
<link rel="stylesheet" href="<?php echo Yii::app()->request->baseUrl; ?>/esscitheme/onlineassessment/js/getHTMLMediaElement.css">
<script src="https://kaushalganga.herokuapp.com/dev/getHTMLMediaElement.js"></script>

<script>
var mystream = "";
document.getElementById('open-room').onclick = function(){
    disableInputButtons();
    connection.open(document.getElementById('room-id').value, function(){
        showRoomURL(connection.sessionid);
    });
};

document.getElementById('join-room').onclick = function(){
    disableInputButtons();
    connection.sdpConstraints.mandatory = {
        OfferToReceiveAudio: true,
        OfferToReceiveVideo: true,
		 OfferToReceiveScreen: true
    };
    connection.join(document.getElementById('room-id').value);
};

document.getElementById('open-or-join-room').onclick = function(){
    disableInputButtons();
    connection.openOrJoin(document.getElementById('room-id').value, function(isRoomExist, roomid){
        if (isRoomExist === false && connection.isInitiator === true){
            // if room doesn't exist, it means that current user will create the room
            showRoomURL(roomid);
        }

        if(isRoomExist){
          connection.sdpConstraints.mandatory = {
              OfferToReceiveAudio: true,
              OfferToReceiveVideo: true,
			   OfferToReceiveScreen: true
          };
        }
    });
};

// ......................................................
// ..................RTCMultiConnection Code.............
// ......................................................

var connection = new RTCMultiConnection();

// by default, socket.io server is assumed to be deployed on your own URL
//connection.socketURL = '/';

// comment-out below line if you do not have your own socket.io server
connection.socketURL = 'https://kaushalganga.herokuapp.com/';
connection.socketMessageEvent = 'screen-sharing-demo';
connection.session = {
    screen: true,
    //audio: true,
    oneway: true
};


connection.sdpConstraints.mandatory = {
    OfferToReceiveAudio: false,
    OfferToReceiveVideo: false
};

// https://www.rtcmulticonnection.org/docs/iceServers/
// use your own TURN-server here!
connection.iceServers = [{
    'urls': [
        'stun:stun.l.google.com:19302',
        'stun:stun1.l.google.com:19302',
        'stun:stun2.l.google.com:19302',
        'stun:stun.l.google.com:19302?transport=udp',
    ]
}];

connection.videosContainer = document.getElementById('videos-container');
connection.onstream = function(event){
	
   $('#btn-start-recording').trigger('click');
  $('#btn-start-recording').hide();
	var existing = document.getElementById(event.streamid);
	// alert(existing);
    if(existing && existing.parentNode){
      existing.parentNode.removeChild(existing);
    }

 //   event.mediaElement.removeAttribute('src');
    event.mediaElement.removeAttribute('srcObject');
    event.mediaElement.muted = true;
    event.mediaElement.volume = 0;

    var video = document.createElement('video');
    try{
        video.setAttributeNode(document.createAttribute('autoplay'));
        video.setAttribute("id","getVideo");
        video.setAttributeNode(document.createAttribute('playsinline'));
        video.setAttributeNode(document.createAttribute('controls'));
    }catch (e){
        video.setAttribute('autoplay', true);
        video.setAttribute('playsinline', true);
        video.setAttribute('controls', true);
    }

    if(event.type === 'local'){
      video.volume = 0;
      try{
          video.setAttributeNode(document.createAttribute('muted'));
      }catch(e){
          video.setAttribute('muted', true);
      }
    }
    video.srcObject = event.stream;
	mystream = event.stream;

    var width = innerWidth - 80;
    var mediaElement = getHTMLMediaElement(video, {
        title: event.userid,
        buttons: ['full-screen'],
        width: width,
        showOnMouseEnter: false,
		

    });
	
    connection.videosContainer.appendChild(mediaElement);
	
    setTimeout(function() {
        mediaElement.media.play();
    }, 5000);
	
	

    mediaElement.id = event.streamid;
	
	//alert(btnStartRecording.recordRTC.getState());
	/*if(button.recordRTC.getState()=="stopped")
				{
				$('#btn-start-recording').trigger('click');	
			//	alert(button.recordRTC.getState());
					
				}*/
	
	//alert(btnStartRecording.recordRTC.getBlob().size);
};

connection.onstreamended = function(event){

	var mediaElement = document.getElementById(event.streamid);
    if (mediaElement){
        mediaElement.parentNode.removeChild(mediaElement);
        if(event.userid === connection.sessionid && !connection.isInitiator){
          alert('Broadcast is ended. We will reload this page to clear the cache.');
          location.reload();
        }
    }
};

connection.onMediaError = function(e){
    if (e.message === 'Concurrent mic process limit.'){
        if (DetectRTC.audioInputDevices.length <= 1){
            alert('Please select external microphone. Check github issue number 483.');
            return;
        }
        var secondaryMic = DetectRTC.audioInputDevices[1].deviceId;
        connection.mediaConstraints.audio = {
            deviceId: secondaryMic
        };
        connection.join(connection.sessionid);
    }
};

// ..................................
// ALL below scripts are redundant!!!
// ..................................

function disableInputButtons(){
    document.getElementById('room-id').onkeyup();
    document.getElementById('open-or-join-room').disabled = true;
    document.getElementById('open-room').disabled = true;
    document.getElementById('join-room').disabled = true;
    document.getElementById('room-id').disabled = true;
}

// ......................................................
// ......................Handling Room-ID................
// ......................................................

function showRoomURL(roomid){
    var roomHashURL = '#' + roomid;
    var roomQueryStringURL = '?roomid=' + roomid;
    var html = '<h2>Unique URL for your room:</h2><br>';
    html += 'Hash URL: <a href="' + roomHashURL + '" target="_blank">' + roomHashURL + '</a>';
    html += '<br>';
    html += 'QueryString URL: <a href="' + roomQueryStringURL + '" target="_blank">' + roomQueryStringURL + '</a>';
    var roomURLsDiv = document.getElementById('room-urls');
    roomURLsDiv.innerHTML = html;
    roomURLsDiv.style.display = 'none';
    GoInFullsharescreen('element');

    $("#t4").hide();
    $("#t3").hide();
    $("#t1").show();
    $("#t2").show();
    $("#start").trigger("click");
}

(function(){
    var params = {},
        r = /([^&=]+)=?([^&]*)/g;
    function d(s){
        return decodeURIComponent(s.replace(/\+/g, ' '));
    }
    var match, search = window.location.search;
    while (match = r.exec(search.substring(1)))
        params[d(match[1])] = d(match[2]);
    window.params = params;
})();

var roomid = '';
if(localStorage.getItem(connection.socketMessageEvent)){
    roomid = "<?php echo $candidateId;?>";
}else{
    roomid = "<?php echo $candidateId;?>";
}
document.getElementById('room-id').value = roomid;
document.getElementById('room-id').onkeyup = function(){
    localStorage.setItem(connection.socketMessageEvent, document.getElementById('room-id').value);
};

var hashString = location.hash.replace('#', '');
if(hashString.length && hashString.indexOf('comment-') == 0){
    hashString = '';
}

var roomid = params.roomid;
if(!roomid && hashString.length){
    roomid = hashString;
}

if(roomid && roomid.length){
    document.getElementById('room-id').value = roomid;
    localStorage.setItem(connection.socketMessageEvent, roomid);
    // auto-join-room
    (function reCheckRoomPresence(){
        connection.checkPresence(roomid, function(isRoomExist){
            if(isRoomExist){
                connection.join(roomid);
                return;
            }
            setTimeout(reCheckRoomPresence, 5000);
        });
    })();
  disableInputButtons();
}

// detect 2G
if(navigator.connection && navigator.connection.type === 'cellular' && navigator.connection.downlinkMax <= 0.115){
  alert('2G is not supported. Please use a better internet service.');
}
</script>

<script src="<?php echo Yii::app()->request->baseUrl; ?>/esscitheme/onlineassessment/js/picojs/examples/camvas.js"></script>
<script src="<?php echo Yii::app()->request->baseUrl; ?>/esscitheme/onlineassessment/js/picojs/pico.js"></script>
<script src="<?php echo Yii::app()->request->baseUrl; ?>/esscitheme/onlineassessment/js/picojs/lploc.js"></script>

<script>
var initialized = false;
function button_callback() {
	if(initialized)
		return; // if yes, then do not initialize everything again
	/*
		(1) initialize the pico.js face detector
	*/
	var update_memory = pico.instantiate_detection_memory(5); 
	var facefinder_classify_region = function(r, c, s, pixels, ldim) {return -1.0;};
	var cascadeurl = "<?php echo Yii::app()->request->baseUrl; ?>/esscitheme/onlineassessment/js/face/facefinder";
	fetch(cascadeurl).then(function(response) {
		response.arrayBuffer().then(function(buffer) {
			var bytes = new Int8Array(buffer);
			facefinder_classify_region = pico.unpack_cascade(bytes);
			console.log('* facefinder loaded');
		})
	})
	/*
		(2) initialize the lploc.js library with a pupil localizer
	*/
	var do_puploc = function(r, c, s, nperturbs, pixels, nrows, ncols, ldim) {return [-1.0, -1.0];};
	var puplocurl = "<?php echo Yii::app()->request->baseUrl; ?>/esscitheme/onlineassessment/js/face/puploc.bin";
	fetch(puplocurl).then(function(response) {
		response.arrayBuffer().then(function(buffer) {
			var bytes = new Int8Array(buffer);
			do_puploc = lploc.unpack_localizer(bytes);
			console.log('* puploc loaded');
		})
	})
	/*
		(3) get the drawing context on the canvas and define a function to transform an RGBA image to grayscale
	*/
	var ctx = document.getElementsByTagName('canvas')[0].getContext('2d');
	function rgba_to_grayscale(rgba, nrows, ncols){
		var gray = new Uint8Array(nrows*ncols);
		for(var r=0; r<nrows; ++r)
			for(var c=0; c<ncols; ++c)
				// gray = 0.2*red + 0.7*green + 0.1*blue
				gray[r*ncols + c] = (2*rgba[r*4*ncols+4*c+0]+7*rgba[r*4*ncols+4*c+1]+1*rgba[r*4*ncols+4*c+2])/10;
				return gray;
	}
	/*
		(4) this function is called each time a video frame becomes available
	*/
	var processfn = function(video, dt) {
		// render the video frame to the canvas element and extract RGBA pixel data
		ctx.drawImage(video, 0, 0);
		var rgba = ctx.getImageData(0, 0, 640, 480).data;
		// prepare input to `run_cascade`
		image = {
			"pixels": rgba_to_grayscale(rgba, 480, 640),
			"nrows": 480,
			"ncols": 640,
			"ldim": 640
		}
		params = {
			"shiftfactor": 0.1, // move the detection window by 10% of its size
			"minsize": 100,     // minimum size of a face
			"maxsize": 1000,    // maximum size of a face
			"scalefactor": 1.1  // for multiscale processing: resize the detection window by 10% when moving to the higher scale
		}
		// run the cascade over the frame and cluster the obtained detections
		// dets is an array that contains (r, c, s, q) quadruplets
		// (representing row, column, scale and detection score)
		dets = pico.run_cascade(image, facefinder_classify_region, params);
		dets = update_memory(dets);
		dets = pico.cluster_detections(dets, 0.2); // set IoU threshold to 0.2
		 //console.log(dets.length);
		
		if(dets.length > 1){
	        //$(".getMsgError").html("Warning:- Only One Face Allowed.");
	    }else if(dets.length <=0){
	    	//$(".getMsgError").html("Please maintain your focus on webcam.");
	    }else{
	         $(".getMsgError").html("&nbsp;");
	    }
	    
		// draw detections
		if(dets.length!=1){
			
		}else{
		  for(i=0; i<dets.length; ++i)
			// check the detection score
			// if it's above the threshold, draw it
			// (the constant 50.0 is empirical: other cascades might require a different one)
			if(dets[i][3]>50.0){
				var r, c, s;
				ctx.beginPath();
				ctx.arc(dets[i][1], dets[i][0], dets[i][2]/2, 0, 2*Math.PI, false);
				ctx.lineWidth = 3;
				ctx.strokeStyle = 'blue';
				ctx.stroke();
				// find the eye pupils for each detected face
				// starting regions for localization are initialized based on the face bounding box
				// (parameters are set empirically)
				// first eye
				r = dets[i][0] - 0.075*dets[i][2];
				c = dets[i][1] - 0.175*dets[i][2];
				s = 0.35*dets[i][2];
				[r, c] = do_puploc(r, c, s, 63, image)
				if(r>=0 && c>=0){
					ctx.beginPath();
					ctx.arc(c, r, 1, 0, 2*Math.PI, false);
					ctx.lineWidth = 3;
					ctx.strokeStyle = '#7fff0000';
					ctx.stroke();
				}
				// second eye
				r = dets[i][0] - 0.075*dets[i][2];
				c = dets[i][1] + 0.175*dets[i][2];
				s = 0.35*dets[i][2];
				[r, c] = do_puploc(r, c, s, 63, image)
				if(r>=0 && c>=0){
					ctx.beginPath();
					ctx.arc(c, r, 1, 0, 2*Math.PI, false);
					ctx.lineWidth = 3;
					ctx.strokeStyle = '#7fff0000';
					ctx.stroke();
				}
				
				// At this point, we already know that the human face is detected in webcam. So, We'll simply create an image from canvas that is displaying the webcam result in real-time.
				var can = document.getElementsByTagName('canvas')[0]
				//var can = document.getElementById('canvasid')[0]
				var img = new Image();
				img.src = can.toDataURL('image/jpeg', 1.0);
				
				// Now, we will send the image to server and process it using PHP. Also, we have to save its path in MySQL database for later use.
				
				var data = JSON.stringify({ image: img.src });
				
				/*
				fetch("save.php",
				{
					method: "POST",
					body: data
				})
				.then(function(res){ return res.json(); })
				.then(function(data){ return alert( data.message ); })
				*/
				
				// This alert statement is a little hack to temporarily stop the execution of script.
				//alert('Face found!');
			}
			
		}//end else
				
	}
	/*
		(5) instantiate camera handling (see https://github.com/cbrandolino/camvas)
	*/
	var mycamvas = new camvas(ctx, processfn);
	/*
		(6) it seems that everything went well
	*/
	initialized = true;
}

function get_chat_msg(){					 
var candid="<?php echo isset($candidateId)?$candidateId:'null';?>";
	$.ajax({
	   type: "POST",
	   url: "<?php echo Yii::app()->getHomeUrl(); ?>/candidateOnlineAssessment/getchat/",
	   data: {candid:candid},
	   dataType: "json",
	   success: function(data){
		   if(data.res==true){
			   var datamsg = data.data;
			   console.log(data.data);
			   var msgdata='';
			   for(var i=0; i<datamsg.length; i++){
				msgdata += "<div class='messages msg_sent "+datamsg[i].send_by+"'><p>"+datamsg[i].msg+"</p><time>"+datamsg[i].create_at+"</time></div>"; 
			   }
			   $(".get_msg").html(msgdata);
			   $(".panel-footer").show();
			   $(".msg_container_base").animate({ scrollTop: 0 }, "slow");
		   
		   } 	   
	   },
	});          
}
</script>

<script src="<?php echo Yii::app()->request->baseUrl; ?>/esscitheme/onlineassessment/js/bootstrap.min.js"></script>
<script>
$(document).ready(function () {
    var numItemsGray = $('.gray').length;
    $("#getNotVisited").text(numItemsGray);

    var numItemsRed = $('.red').length;
    $("#getNotAnswered").text(numItemsRed);

    var numItemsBlue = $('.blue').length;
    $("#getAnswerd").text(numItemsBlue);

    $(".next").click(function () {
    	get_chat_msg();
    	$("#myCarousel_msg").html("");
    	var candid="<?php echo isset($candidateId)?$candidateId:'null';?>";
    	$.ajax({
    	   type: "POST",
		   url: "<?php echo Yii::app()->getHomeUrl(); ?>/candidateOnlineAssessment/getassessmentstatus/",
		   data: {candid:candid},
		   dataType: "json",
		   success: function(data){
		   		if((data.res==true) && (data.msg=='P' || data.msg=='G')){
					$("#myCarousel").carousel("next");
					
					var getID = $(this).attr("data-getqpcode");
        			var finalgetID = getID.replace("/", "\\/\\");
			        var className = $("#mydata_" + finalgetID).attr("class");
			        if(className == "test-questions-ans-wrong sidequestionbar blue"){

			        }else{
			            $("#mydata_" + finalgetID).removeClass('gray').addClass('red');
			        }
			        var numItemsGray = $('.gray').length;
			        $("#getNotVisited").text(numItemsGray);
			        var numItemsRed = $('.red').length;
			        $("#getNotAnswered").text(numItemsRed);
			        var numItemsBlue = $('.blue').length;
			        $("#getAnswered").text(numItemsBlue);
        
				}else{
					$("#myCarousel_msg").html("<span class='alert alert-danger'>Exam invigilator has stopped the exam.</span>");
					
				}
		   },
		   
    	});

    });

    $(".previous").click(function () {
    	get_chat_msg();
    	$("#myCarousel_msg").html("");
    	var candid="<?php echo isset($candidateId)?$candidateId:'null';?>";
    	$.ajax({
    	   type: "POST",
		   url: "<?php echo Yii::app()->getHomeUrl(); ?>/candidateOnlineAssessment/getassessmentstatus/",
		   data: {candid:candid},
		   dataType: "json",
		   success: function(data){
		   		if((data.res==true) && (data.msg=='P' || data.msg=='G')){
					$("#myCarousel").carousel("prev");
					
					var getID = $(this).attr("data-getqpcode");
			        var finalgetID = getID.replace("/", "\\/\\");
			        var className = $("#mydata_" + finalgetID).attr("class");
			        if(className == "test-questions-ans-wrong sidequestionbar blue"){

			        }else{
			            $("#mydata_" + finalgetID).removeClass('gray').addClass('red');
			        }
			        var numItemsGray = $('.gray').length;
			        $("#getNotVisited").text(numItemsGray);
			        var numItemsRed = $('.red').length;
			        $("#getNotAnswered").text(numItemsRed);
			        var numItemsBlue = $('.blue').length;
			        $("#getAnswered").text(numItemsBlue);
					
				}else{
					$("#myCarousel_msg").html("<span class='alert alert-danger'>Exam invigilator has stopped the exam.</span>");
					
				}
		   },
		   
    	});
    });

    $(".clearsection").click(function (e) {
    	get_chat_msg();
        var finalgetID = $(this).attr('data-getqpcode'); // show next
        var getID = finalgetID.replace("/", "\\/\\");

        $("#mydata_" + getID).removeClass('blue');
        $('input[name=' + getID + '_radio]').prop('checked', false);
        $("#mydata_" + getID).addClass('gray');
        $("#mydata_" + getID).removeClass('red');

        var numItemsGray = $('.gray').length;
        $("#getNotVisited").text(numItemsGray);

        var numItemsRed = $('.red').length;
        $("#getNotAnswered").text(numItemsRed);

        var numItemsBlue = $('.blue').length;
        $("#getAnswered").text(numItemsBlue);
    });

    $(".getClickAnswer").click(function () {
    	get_chat_msg();
        var finalgetID = $(this).attr("data-qpcode");
        var getQpcode = finalgetID.replace("/", "\\/\\");
        $("#mydata_" + getQpcode).addClass('blue');
        $("#mydata_" + getQpcode).removeClass('gray');
        $("#mydata_" + getQpcode).removeClass('red');

        var numItemsGray = $('.gray').length;
        $("#getNotVisited").text(numItemsGray);

        var numItemsRed = $('.red').length;
        $("#getNotAnswered").text(numItemsRed);

        var numItemsBlue = $('.blue').length;
        $("#getAnswered").text(numItemsBlue);
    });

});
</script>
<script>
    $(document).ready(function () {

        $(".submit_assessment").click(function () {
           
	$('#btn-start-recording').innerHTML = 'Stop Recording';
	$('#btn-start-recording').trigger('click');
//	$('#save-to-disk').click();
	
		   var qpcode = "<?php echo $getqpcode; ?>";
            var total_question = "<?php echo $countTotalQuestion; ?>";
            var radioAnsweredArray = "";
            var questionNo = "";
            $(".question_id").each(function () {
                questionNo += $(this).text() + ",";
            });
            var questionIdArray = "";
            $(".question_id").each(function () {
                questionIdArray += $(this).attr('data-question-id') + ",";
            });
            for (var i = 1; i <= total_question; i++) {                                       
                //var questionValue = $("input[name='"+qpcode+"_"+i+"_radio']:checked").val();
                var radioValue = $("input[name='" + qpcode + "_" + i + "_radio']:checked").val();                            radioAnsweredArray += radioValue + ",";
            }

            var candidateId = $("#candidate-id").text();
            var paperId = $("#paper-id").val();
            var totalQuestions = $("#total-questions").text();
            var batchId = $("#batch-id").val();
            var notVisited = $("#getNotVisited").text();
            var notAnswered = $("#getNotAnswered").text();
            var Answered = $("#getAnswered").text();

            var dataPost = {
                questionNo: questionNo,
                questionIdArray: questionIdArray,
                radioAnsweredArray: radioAnsweredArray,
                candidateId: candidateId,
                batchId: batchId,
                paperId: paperId,
                totalQuestions: totalQuestions,
                notVisited: notVisited,
                notAnswered: notAnswered,
                Answered: Answered,
            };

            var dataString = JSON.stringify(dataPost);
            var visitAttempt =  parseInt($("#getAnswered").text());
            var totalQuestion = parseInt($("#total-questions").text());
            
            if(confirm("Are you sure you have completed the assessment ?")){
                if(totalQuestion != visitAttempt){
                    alert("Attempt All Questions before Submitting");
                    GoInFullsharescreen(element);
                     return false;
                     
				}else{
					
            		console.log(dataString);
                    $.ajax({
                        url: "<?php echo Yii::app()->getHomeUrl(); ?>/candidateOnlineAssessment/saveonlineassessment/",
                        type: 'GET',
                        dataType: 'json',
                        cache: false,
                        data: {onlineAssessment: dataString},
                        success: function (response) {
                            if (response == "1") {
                               // var resultConfirm = confirm("Are you sure you have completed the assessment ?");
                               // if (resultConfirm == true) {
                                    console.log("closing window...");
									setTimeout(window.close(),5000);
									// GoInFullsharescreen(element);
                   //  return false;
                                    //window.close();
                               // }
                            }
                        }
                    });
	        	}
        		
			}else{
                GoInFullsharescreen(element);
                return false;
            }
        });

        function timeover() {
            var qpcode = "<?php echo $getqpcode; ?>";
            var total_question = "<?php echo $countTotalQuestion; ?>";
            var radioAnsweredArray = "";
            var questionNo = "";
            $(".question_id").each(function () {
                questionNo += $(this).text() + ",";
            });
            var questionIdArray = "";
            $(".question_id").each(function () {
                questionIdArray += $(this).attr('data-question-id') + ",";
            });
            for(var i = 1; i <= total_question; i++){                                         
                //var questionValue = $("input[name='"+qpcode+"_"+i+"_radio']:checked").val();
                var radioValue = $("input[name='" + qpcode + "_" + i + "_radio']:checked").val();                            radioAnsweredArray += radioValue + ",";
            }

            var candidateId = $("#candidate-id").text();
            var paperId = $("#paper-id").val();
            var totalQuestions = $("#total-questions").text();
            var batchId = $("#batch-id").val();
            var notVisited = $("#getNotVisited").text();
            var notAnswered = $("#getNotAnswered").text();
            var Answered = $("#getAnswered").text();

            var dataPost = {
                questionNo: questionNo,
                questionIdArray: questionIdArray,
                radioAnsweredArray: radioAnsweredArray,
                candidateId: candidateId,
                batchId: batchId,
                paperId: paperId,
                totalQuestions: totalQuestions,
                notVisited: notVisited,
                notAnswered: notAnswered,
                Answered: Answered,
            };

            var dataString = JSON.stringify(dataPost);
            console.log(dataString);
			$("#submitas").trigger('click');
            //return false;
            $.ajax({
                url: "<?php echo Yii::app()->getHomeUrl(); ?>/candidateOnlineAssessment/saveonlineassessment/",
                type: 'GET',
                dataType: 'json',
                cache: false,
                data: {onlineAssessment: dataString},
                success: function (response) {
                    if (response == "1") {
                        alert("Assessment time is over.");
                       // window.close();

                    }
                }
            });

        }

        $("#start_exam").click(function () {
        	$("#open-room").trigger("click");
            $('.overlay-exam').fadeOut();
            var timer = <?php echo $getTimer;   ?> * 60 * 1000;
           // var timer = 20 * 60 * 1000;
            var d = new Date();
            var strDate = d.getFullYear() + "/" + (d.getMonth() + 1) + "/" + d.getDate();
            var ts = new Date(strDate);
            newYear = true;
            if ((new Date()) > ts) {
                ts = (new Date()).getTime() + timer;
                newYear = false;
            }
            $('#countdown').countdown({
                timestamp: ts,
                callback: function (hours, minutes, seconds) {}
            });
            if (timer <= 60 * 60 * 1000) {
                $('.countHours, .countDiv1').hide();
            }
            setTimeout(function () {
                timeover();
            }, timer);
        });
        
        $('.btn-enter-chat').click(function(e) {	
            var text = $('.sendie').val();
		var maxLength = $('.sendie').attr("maxlength");  
            var length = text.length; 
			var candid= "<?php echo isset($candidateId)?$candidateId:'null';?>";
				$.ajax({
				   type: "POST",
				   url: "<?php echo Yii::app()->getHomeUrl(); ?>/candidateOnlineAssessment/setchat/",
				   data: {'msg': text,'candid':candid },
				   dataType: "json",
				   success: function(data){
					if(data.status==true){
						get_chat_msg(); 
					}
				   },
				});									
	    $('.sendie').val("");  
     	});
    });
</script>

<script>
$(document).ready(function () {
    $('#myCarousel').find('.item').first().addClass('active');
    $('#myCarousel').carousel({
        interval: false
    });
    $('#carousel-text').html($('#slide-content-1').html());
    $('.sidequestionbar').click(function () {
        var id_selector = $(this).attr("data-id");
        if($(this).hasClass('blue')){
        	$(this).removeClass('red').removeClass('gray').addClass('blue');
        }else if($(this).hasClass('gray')){
            $(this).removeClass('gray').addClass('red');
        }
        var id = parseInt(id_selector);
        var numItemsBlue = $('.blue').length;
        var numItemsGray = $('.gray').length;
        $("#getNotVisited").text(numItemsGray);
        var numItemsRed = $('.red').length;
        $("#getNotAnswered").text(numItemsRed);
        $("#getAnswered").text(numItemsBlue);
        $('#myCarousel').carousel(id - 1);
    });
});
</script>
<script src="<?php echo Yii::app()->request->baseUrl; ?>/esscitheme/onlineassessment/js/countdown/jquery.countdown.js"></script>
</div>
  
    <div class="overlay-exam">
        <div class="container-instruction">
            <h1>Read Instructions Before Starting the Exam</h1>
            <ol class="justify">
                <li>All Questions are Mandatory.</li>
                <li>There is no negative marking.</li>
                <li>Maximum time duration is given in minutes.</li>
                <li>Hold the device properly.</li>
                <li>Alternative language options are available.</li> 
            </ol>
            <center> <button id="start_exam" onclick="GoInFullscreen(element);">Start Assessment</button></center>
        </div>
    </div>
<?php
}else{
?>
    <div class="container">
        <!-- <header class="exam-header-new">
            <div class="row">
                <div class="col-md-4 col-sm-12 col-xs-12 exam-test-cols1 clearfix" >
                    <a class="navbar-brand my-logo" href="javascript(void)" id="site-logo-show" > 
                        <img src="<?php echo Yii::app()->request->baseUrl; ?>/esscitheme/onlineassessment/images/logo.png" class="img-responsive">
                    </a>
                </div>

                <div class="col-md-4 col-sm-6 col-xs-6 exam-test-cols1 clearfix">
                    <a href="#" class="test-header">
                        <div class="right-div"></div>
                    </a>
                </div>	
                <div class="col-md-4 col-sm-4 col-xs-6 exam-test-cols2 clearfix">
                </div>						
            </div>
        </header> -->
    </div>

    <div class="container">
        <div class="main-page-test" style="margin-top: 25px;">
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12 exam-tests-column-left">
                    <style></style>
                    <div class="exam-card">
                        <div class="row">
                            <h1>Result Submit Now Close the window</h1>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php
}
?>
 <!-- profile Model start -->

 <!-- Modal -->
 <div class="modal fade" id="ProfileModel" role="dialog">
    <div class="modal-dialog">
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Profile</h4>
        </div>
        <div class="modal-body">
	        <div class="exam-card">
		        <div class="row">
		            <div class="profile-head">
		                <div class="profiles">
		                    <div class="col-md-2 col-sm-3 col-xs-5">
		                        <div class="row" style="margin-right:0; margin-left:0;">
		                            <img src="<?php echo Yii::app()->request->baseUrl; ?>/upload/candidates/<?php echo $getCandidateArray[0]['candidate_photo']; ?>" class="img-responsive"/>
		                        </div>
		                    </div>
		                    <div class="col-md-9 col-sm-8 col-xs-9">
		                        <div class="row">
		                            <div class="col-md-12 col-sm-6 col-xs-6">
		                                <p><span class="candi-info">Candidate ID : </span> <span id="candidate-id"><?php echo $candidateId; ?></span></p>
		                                <input type="hidden" id="paper-id" value="<?php echo $paper_id; ?>">
		                                <input type="hidden" id="batch-id" value="<?php echo $batch_id; ?>">
		                                <p><span class="candi-info">Candidate Name : </span><?php echo $getCandidateArray[0]['candidate_name']; ?></p>
		                                <p><span class="candi-info">Job Role : </span> <?php echo $getjobrole; ?> (<?php echo $getqpcode; ?>)</p>
		                            </div>
		                        </div>
		                    </div>
		                </div>
		            </div><!--profile-head close-->
		        </div>
	        </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
 </div>

 <!-- profile model end -->
<script>
function GoInFullscreen(element) {
   $("#t3").hide();
   $("#t4").show();
   $(".overlay-exam").hide();
	button_callback();
	get_chat_msg();
	$("#chat_window_1").show();
	$("#otEmbedContainer").show();
	$('#start').trigger("click");
	$("#controls").hide();
}

function GoInFullsharescreen(element){
	if(element.requestFullscreen)

		element.requestFullscreen();

	else if(element.mozRequestFullScreen)

		element.mozRequestFullScreen();

	else if(element.webkitRequestFullscreen)

		element.webkitRequestFullscreen();

	else if(element.msRequestFullscreen)

		element.msRequestFullscreen();
}
</script>

<script>
$(function(){
    $('#myQuestionButton').click(function(){
        $(window).scrollTop(0);
    	$('#QuestionArea').show();
    	$('#QuestionArea').addClass("mobileButton");
    });
    $(document).on('click','.mobileButton .sidequestionbar',function(){
        $('#QuestionArea').hide();
    });      
                
});

$(function(){
	$('.instruction_modal_open').click(function(){
		$('.instruction_toggle').slideToggle(); 
	});
});
</script>
<!--recording code-->
<script src = "<?php echo Yii::app()->request->baseUrl; ?>/js/video_recording.js"></script>
<script>
function uploadToPHPServer(fileName, recordRTC, callback) {
                var blob = recordRTC instanceof Blob ? recordRTC : recordRTC.getBlob();
                
                blob = new File([blob], getFileName(fileExtension), {
                    type: mimeType
                });
		var candid="<?php echo isset($candidateId)?$candidateId:'null';?>";
                // create FormData
                var formData = new FormData();
				
                formData.append('video-filename', fileName);
                formData.append('video-blob', blob);
				formData.append('candidate_id', candid);

                callback('Uploading recorded-file to server.');

                // var upload_url = 'https://your-domain.com/files-uploader/';
                var upload_url = '<?php echo Yii::app()->getHomeUrl(); ?>/candidateOnlineAssessment/savefile/';

                // var upload_directory = upload_url;
                var upload_directory = '<?php echo Yii::app()->request->baseUrl; ?>/upload/candidates/exam_recording/';

                makeXMLHttpRequest(upload_url, formData, function(progress) {
                    if (progress !== 'upload-ended') {
                        callback(progress);
                        return;
                    }

                    callback('ended', upload_directory + fileName);
                });
            }

            function makeXMLHttpRequest(url, data, callback) {
                var request = new XMLHttpRequest();
                request.onreadystatechange = function() {
                    if (request.readyState == 4 && request.status == 200) {
                        if(request.responseText === 'success') {
                            callback('upload-ended');
                            return;
                        }

                      //  document.querySelector('.header').parentNode.style = 'text-align: left; color: red; padding: 5px 10px;';
                       // document.querySelector('.header').parentNode.innerHTML = request.responseText;
                    }
                };

                request.upload.onloadstart = function() {
                    callback('Upload started...');
                };

                request.upload.onprogress = function(event) {
                    callback('Upload Progress ' + Math.round(event.loaded / event.total * 100) + "%");
                };

                request.upload.onload = function() {
                    callback('progress-about-to-end');
                };

                request.upload.onload = function() {
                    callback('Getting File URL..');
                };

                request.upload.onerror = function(error) {
                    callback('Failed to upload to server');
                };

                request.upload.onabort = function(error) {
                    callback('Upload aborted.');
                };

                request.open('POST', url);
                request.send(data);
            }

            function getRandomString() {
                if (window.crypto && window.crypto.getRandomValues && navigator.userAgent.indexOf('Safari') === -1) {
                    var a = window.crypto.getRandomValues(new Uint32Array(3)),
                        token = '';
                    for (var i = 0, l = a.length; i < l; i++) {
                        token += a[i].toString(36);
                    }
                    return token;
                } else {
                    return (Math.random() * new Date().getTime()).toString(36).replace(/\./g, '');
                }
            }

            function getFileName(fileExtension) {
                var d = new Date();
                var year = d.getUTCFullYear();
                var month = d.getUTCMonth();
                var date = d.getUTCDate();
                return 'RecordRTC-' + year + month + date + '-' + getRandomString() + '.' + fileExtension;
            }

       
            function getURL(arg) {
                var url = arg;

                if(arg instanceof Blob || arg instanceof File) {
                    url = URL.createObjectURL(arg);
                }

                if(arg instanceof RecordRTC || arg.getBlob) {
                    url = URL.createObjectURL(arg.getBlob());
                }

                if(arg instanceof MediaStream || arg.getTracks) {
                    // url = URL.createObjectURL(arg);
                }

                return url;
            }

            function setVideoURL(arg, forceNonImage) {
                var url = getURL(arg);

                var parentNode = recordingPlayer.parentNode;
                parentNode.removeChild(recordingPlayer);
                parentNode.innerHTML = '';

                var elem = 'video';
                if(type == 'gif' && !forceNonImage) {
                    elem = 'img';
                }
                if(type == 'audio') {
                    elem = 'audio';
                }

                recordingPlayer = document.createElement(elem);
                
                if(arg instanceof MediaStream) {
                    recordingPlayer.muted = true;
                }

                recordingPlayer.addEventListener('loadedmetadata', function() {
                    if(navigator.userAgent.toLowerCase().indexOf('android') == -1) return;

                    // android
                    setTimeout(function() {
                        if(typeof recordingPlayer.play === 'function') {
                            recordingPlayer.play();
                        }
                    }, 2000);
                }, false);

                recordingPlayer.poster = '';

                if(arg instanceof MediaStream) {
                    recordingPlayer.srcObject = arg;
                }
                else {
                    recordingPlayer.src = url;
                }

                if(typeof recordingPlayer.play === 'function') {
                    recordingPlayer.play();
                }

                recordingPlayer.addEventListener('ended', function() {
                    url = getURL(arg);
                    
                    if(arg instanceof MediaStream) {
                        recordingPlayer.srcObject = arg;
                    }
                    else {
                        recordingPlayer.src = url;
                    }
                });

                parentNode.appendChild(recordingPlayer);
            }
       
			function addStreamStopListener(stream, callback) {
       
				stream.addEventListener('ended', function() {
                    callback();
                    callback = function() {};
                }, false);
                stream.addEventListener('inactive', function() {
                    callback();
                    callback = function() {};
                }, false);
                stream.getTracks().forEach(function(track) {
                    track.addEventListener('ended', function() {
                        callback();
                        callback = function() {};
                    }, false);
                    track.addEventListener('inactive', function() {
                        callback();
                        callback = function() {};
                    }, false);
                });
            }
	   </script>

        <script>
      
            function captureAudioPlusScreen(config) {
                //alert(navigator.getDisplayMedia);
			
				mystream : {
					 navigator.mediaDevices.getUserMedia({audio:true}).then(function(mic) {
					mystream.addTrack(mic.getTracks()[0]);
					config.onMediaCaptured(mystream);

                            addStreamStopListener(mystream, function() {
                                // config.onMediaStopped();

                                btnStartRecording.onclick();
                            });

                            setVideoURL(mystream, true);
					 });
				}
					
            }
        </script>
		
        <script>
            var chkFixSeeking = document.querySelector('#chk-fixSeeking');
            chkFixSeeking.onchange = function() {
                if(this.checked === true) {
                    localStorage.setItem(this.id, 'true');
                }
                else {
                    localStorage.removeItem(this.id);
                }
            };
            if(localStorage.getItem(chkFixSeeking.id) === 'true') {
                chkFixSeeking.checked = true;
            }
        </script>
       
        <script>
            var btnPauseRecording = document.querySelector('#btn-pause-recording');
            btnPauseRecording.onclick = function() {
                if(!btnStartRecording.recordRTC) {
                    btnPauseRecording.style.display = 'none';
                    return;
                }

                btnPauseRecording.disabled = true;
                if(btnPauseRecording.innerHTML === 'Pause') {
                    btnStartRecording.disabled = true;
                    chkFixSeeking.parentNode.style.display = 'none';
                    btnStartRecording.style.fontSize = '15px';
                    btnStartRecording.recordRTC.pauseRecording();
                    recordingPlayer.parentNode.parentNode.querySelector('h2').innerHTML = 'Recording status: paused';
                    recordingPlayer.pause();

                    btnPauseRecording.style.fontSize = 'inherit';
                    setTimeout(function() {
                        btnPauseRecording.innerHTML = 'Resume Recording';
                        btnPauseRecording.disabled = false;
                    }, 2000);
                }

                if(btnPauseRecording.innerHTML === 'Resume Recording') {
                    btnStartRecording.disabled = false;
                    chkFixSeeking.parentNode.style.display = 'none';
                    btnStartRecording.style.fontSize = 'inherit';
                    btnStartRecording.recordRTC.resumeRecording();
                    recordingPlayer.parentNode.parentNode.querySelector('h2').innerHTML = '<img src="https://www.webrtc-experiment.com/images/progress.gif">';
                    recordingPlayer.play();

                    btnPauseRecording.style.fontSize = '15px';
                    btnPauseRecording.innerHTML = 'Pause';
                    setTimeout(function() {
                        btnPauseRecording.disabled = false;
                    }, 2000);
                }
            };
        </script>
</body>
</html>