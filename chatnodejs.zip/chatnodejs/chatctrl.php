<?php

class CandidateOnlineAssessmentController extends Controller {

    /**
     * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
     * using two-column layout. See 'protected/views/layouts/column2.php'.
     */
    public $layout = '//layouts/column4';

    /**
     * @return array action filters
     */
    public function filters() {
        return array(
            'accessControl', // perform access control for CRUD operations
            'postOnly + delete', // we only allow deletion via POST request
        );
    }

    /**
     * Specifies the access control rules.
     * This method is used by the 'accessControl' filter.
     * @return array access control rules
     */
    public function accessRules() {

        if (Yii::app()->user->getState('type') == "C") {
            $arr = array('onlineassessment', 'error', 'searchData','saveonlineassessment','getchat','setchat','redirectafterexam','getassessmentstatus','savefile');   // give all access to admin
        } else if (Yii::app()->user->getState('type') == "S" || Yii::app()->user->getState('type') == "O" || Yii::app()->user->getState('type') == "TE") {
            $arr = array('index', 'error');    // give all access to User
        }else if (Yii::app()->user->getState('type') == "AS") {
            $arr = array('saveonlinepracticalassessment','saveonlinevivaassessment', 'error','Savefeedback','getfeedbacklist','deletefeedback','getchat','setchat','redirectafterexam','getassessmentstatus');    // give all access to User
        }else {
            $arr = array('');          //  no access to other user
        }

        return array(
            array('allow', // allow authenticated user to perform 'create' and 'update' actions
                'actions' => $arr,
                'users' => array('@'),
            ),
            array('deny', // deny all users
                'users' => array('*'),
                'deniedCallback' => function() { Yii::app()->controller->redirect(array ('site/noaccess')); }
            ),
        );
    }

     public function actionDeletefeedback(){
        $candidate_id = isset($_GET['candidate_id'])?$_GET['candidate_id']:'';
        
        
        $deletedone = Yii::app()->db->createCommand("DELETE FROM assessment_feedback WHERE id=$candidate_id")->execute();
        if($deletedone){
            echo 1;
        }else{
            echo 0;
        }
        
        
    }
   public function actionGetfeedbacklist(){
        $candidate_id = isset($_GET['candidate_id'])?$_GET['candidate_id']:'';
        
        
        
        $getfeedback= Yii::app()->db->createCommand("SELECT * FROM assessment_feedback where candidate_id = '".$candidate_id."' ORDER By id DESC")->queryAll();
        echo json_encode($getfeedback);
    }
    
    public function actionSavefeedback(){
              
        if (isset($_GET['feedbackjson'])) {
            $obj = json_decode($_GET["feedbackjson"]);
            
            $candidate_id = $obj->data_candidate_id;
            $batch_id = $obj->batch_id;
            $data_candidate_name = $obj->data_candidate_name;
            
            $message = addslashes($obj->message);
            
            $createdDate = date('Y-m-d h:m:s');
              $saveFeedback = Yii::app()->db->createCommand("INSERT INTO `assessment_feedback` (`id`, `batch_id`, `candidate_id`, `candidate_name`, `message`,`status`, `created_at`, `updated_at`) VALUES (NULL, '" . $batch_id . "', '" . $candidate_id . "', '" . $data_candidate_name . "','" . $message . "','A', '" . $createdDate . "', CURRENT_TIMESTAMP)")->execute();
            
            if($saveFeedback){
                echo 1;
                
            }else{
                echo 0;
            }
             
        }
    }
    
    public function actionOnlineassessment(){
        $candidateId = Yii::app()->user->getState('slug');
        
        $batch_id = isset($_GET['batch_id'])?$_GET['batch_id']:'';
        $paper_id = isset($_GET['paper_id'])?$_GET['paper_id']:'';
        $canididate_id = isset($_GET['candidate_id'])?$_GET['candidate_id']:'';
       
        $getCandidateArray = Yii::app()->db->createCommand("SELECT candidate_name,candidate_photo,online_theory_assessment_status FROM essci_candidate_details where candidate_id ='".$canididate_id."'")->queryAll();
        
        $getTimerArray = Yii::app()->db->createCommand("SELECT paper_set_time,paper_qpcode,paper_jobrole FROM master_generate_paperset where paper_id ='".$paper_id."'")->queryAll();
        $getTimer = isset($getTimerArray[0]['paper_set_time'])?$getTimerArray[0]['paper_set_time']:'';
        $getqpcode = isset($getTimerArray[0]['paper_qpcode'])?$getTimerArray[0]['paper_qpcode']:'';
        $getjobrole = isset($getTimerArray[0]['paper_jobrole'])?$getTimerArray[0]['paper_jobrole']:'';
        
        
       $countTotalQuestion = Yii::app()->db->createCommand("SELECT count(*) As totalQuestion FROM master_generate_questions where paper_id ='".$paper_id."'")->queryAll();
       $countTotalQuestion = isset($countTotalQuestion[0]['totalQuestion'])?$countTotalQuestion[0]['totalQuestion']:'';
        
       $getAssessmentArrayQuestions = Yii::app()->db->createCommand("SELECT * FROM master_generate_questions where paper_id ='".$paper_id."'")->queryAll();
       $getAssessmentQuestions = group_by("nos_code", $getAssessmentArrayQuestions);
       
       $getAssessmentNosQuestions = Yii::app()->db->createCommand("SELECT id,question_id,paper_id,paper_qpcode,nos_code FROM master_generate_questions where paper_id ='".$paper_id."'")->queryAll();
       
       Yii::app()->db->createCommand("UPDATE essci_candidate_details SET online_theory_assessment_status = 'R' WHERE candidate_id='$canididate_id'")->execute();

		$nosCodeArray = group_by("nos_code", $getAssessmentNosQuestions);       
		$countArray = count($getAssessmentQuestions);

//echo "<pre>";
//print_r($getAssessmentQuestions);die;
     //echo $getqpcode;
        $this->renderPartial('onlineassessment', array(
            'candidateId'=>$candidateId,
            'batch_id'=>$batch_id,
            'paper_id'=>$paper_id,
            'getTimer'=>$getTimer,
            'getqpcode'=>$getqpcode,
            'getjobrole'=>$getjobrole,
            'nosCodeArray'=>$nosCodeArray,
            'countArray'=>$countArray,
            'countTotalQuestion'=>$countTotalQuestion,
            'getCandidateArray'=>$getCandidateArray,
            'getAssessmentQuestions'=>$getAssessmentQuestions,
        ));
    }
    
    
    public function actionGetchat(){
		if (isset($_POST['candid'])) {
			$candid =  $_POST["candid"];
			$data = Yii::app()->db->createCommand("SELECT id,candidate_id,proctor_id,msg,send_by,assessment_date,DATE_FORMAT(create_at, '%d-%m-%Y %H:%i') as create_at,status FROM `vp_chat_info` where candidate_id='$candid' ORDER BY id DESC")->queryAll();
			
			$arr = array('res'=>true,'data'=>$data);
	  		  echo json_encode($arr); exit;
		}
	}
	
	
	public function actionSetchat(){
		 if(empty($_POST['msg'])){
			 $arr=array('status'=>false,'msg'=>'message field cannot empty.');
			   echo json_encode($arr);
			   
		 }else{
			 $msg = $_POST['msg'];
			 $candid = $_POST['candid'];
			 $datetime = date('Y-m-d H:i:s');
			 $date = date('Y-m-d');
			 
			 $getdata = Yii::app()->db->createCommand("SELECT * FROM `vp_chat_info` where candidate_id='$candid' AND assessment_date='$date'")->queryRow();
			 
			 $proctorid = $getdata['proctor_id'];
			 
			 $res = Yii::app()->db->createCommand("INSERT INTO `vp_chat_info` (`candidate_id`, `proctor_id`, `type`, `msg`, `send_by`, `assessment_date`, `create_at`, `status`) VALUES ('".$candid."', '".$proctorid."', '".Yii::app()->user->getState('type')."', '".$msg."', 'candidate', '".$date."', '".$datetime."', '1')")->execute();
			 
			 if($res){
				 $arr=array('status'=>true,'msg'=>'Message Sent.');
				  echo json_encode($arr);
				  
			 }else{
				 $arr=array('status'=>false,'msg'=>'something went wrong.');
				  echo json_encode($arr);
				  
			 }
		 }
		
	}
	
	
	public function actionGetassessmentstatus(){
		if (isset($_POST['candid'])){
			$candid =  $_POST["candid"];
			$data = Yii::app()->db->createCommand("SELECT id,batch_id,candidate_id,candidate_name,candidate_online_assessment_status FROM `essci_candidate_details` where candidate_id='$candid' ORDER BY id DESC")->queryRow();
			
			$arr = array('res'=>true,'msg'=>$data['candidate_online_assessment_status']);
	  		  echo json_encode($arr); exit;
		}
	}


    public function actionSavefile(){
		$candidate_id	= $_POST['candidate_id'];
		$post_max_size = '2048M';
		$memory_limit = '2048M';
		$upload_max_filesize = '2048M';
		if (!isset($_POST['audio-filename']) && !isset($_POST['video-filename'])) {
       $arr = array('res'=>false,'msg'=>'Empty file name.');
	  		  echo json_encode($arr); exit;
	
    }

    // do NOT allow empty file names
    if (empty($_POST['video-filename'])) {
        $arr = array('res'=>false,'msg'=>'Empty file name.');
	  		  echo json_encode($arr); exit;
    }

    // do NOT allow third party audio uploads
   
    // do NOT allow third party video uploads
   
    $fileName = '';
    $tempName = '';
    $file_idx = '';
    
   
        $file_idx = 'video-blob';
        $fileName = $_POST['video-filename'];
        $tempName = $_FILES[$file_idx]['tmp_name'];
   
    if (empty($fileName) || empty($tempName)) {
        if(empty($tempName)) {
            
			 $arr = array('res'=>false,'msg'=>'Invalid temp_name: '.$tempName);
	  		  echo json_encode($arr); exit;
        }

      
		 $arr = array('res'=>false,'msg'=>'Invalid file name: '.$fileName);
	  		  echo json_encode($arr); exit;
    }

  
$rand = substr(md5(microtime()),rand(0, 26) , 26);

@$filez = $fileName;

     $ft = 'upload/candidates/exam_recording/'.$_POST['candidate_id'].'/';
	$permit = 0777;
			if(!is_dir($ft)){
				//Directory does not exist, so lets create it.
				

				mkdir($ft);
				
				//mkdir($profilenamepath, 0755);
			}
			chmod($ft, $permit);
	  $filePath = 	$ft.$filez;
    // make sure that one can upload only allowed audio/video files
    $allowed = array(
        'webm',
        'wav',
        'mp4',
        'mkv',
        'mp3',
        'ogg'
    );
	
    $extension = pathinfo($filePath, PATHINFO_EXTENSION);
    if (!$extension || empty($extension) || !in_array($extension, $allowed)) {
      
		 $arr = array('res'=>false,'msg'=>'Invalid file extension: '.$extension);
	  		  echo json_encode($arr); exit;
    }

    if (!move_uploaded_file($tempName, $filePath)) {
        if(!empty($_FILES["file"]["error"])) {
            $listOfErrors = array(
                '1' => 'The uploaded file exceeds the upload_max_filesize directive in php.ini.',
                '2' => 'The uploaded file exceeds the MAX_FILE_SIZE directive that was specified in the HTML form.',
                '3' => 'The uploaded file was only partially uploaded.',
                '4' => 'No file was uploaded.',
                '6' => 'Missing a temporary folder. Introduced in PHP 5.0.3.',
                '7' => 'Failed to write file to disk. Introduced in PHP 5.1.0.',
                '8' => 'A PHP extension stopped the file upload. PHP does not provide a way to ascertain which extension caused the file upload to stop; examining the list of loaded extensions with phpinfo() may help.'
            );
            $error = $_FILES["file"]["error"];

            if(!empty($listOfErrors[$error])) {
                //echo $listOfErrors[$error];
				 $arr = array('res'=>false,'msg'=>$listOfErrors[$error]);
	  		  echo json_encode($arr); exit;
				
            }
            else {
				 $arr = array('res'=>false,'msg'=>'Not uploaded because of error #'.$_FILES["file"]["error"]);
	  		  echo json_encode($arr); exit;
            }
        }
        else {
         
			 $arr = array('res'=>false,'msg'=>'Problem saving file: '.$tempName);
	  		  echo json_encode($arr); exit;
        }
       
    }
    
   // echo 'success';
   Yii::app()->db->createCommand("UPDATE master_online_assessment_result SET exam_recording = '".$filePath."' WHERE candidate_id='".$candidate_id."'")->execute();
   
    Yii::app()->db->createCommand("UPDATE essci_candidate_details SET exam_recording = '".$filePath."' WHERE candidate_id='".$candidate_id."'")->execute();
	 $arr = array('res'=>true,'msg'=>'success');
	  		  echo json_encode($arr); exit;

	}
     public function actionSaveonlineassessment() {
        if (isset($_GET['onlineAssessment'])) {
            $obj = json_decode($_GET["onlineAssessment"]);

            $questionNo = explode(",", substr_replace($obj->questionNo, "", -1));
            $questionIdArray = explode(",", substr_replace($obj->questionIdArray, "", -1));
            $radioAnsweredArray = explode(",", substr_replace($obj->radioAnsweredArray, "", -1));
            $totalQuestions = $obj->totalQuestions;
            $candidateId = $obj->candidateId;

            $batchId = $obj->batchId;
            $notVisited = $obj->notVisited;
            $notAnswered = $obj->notAnswered;
            $Answered = $obj->Answered;
            $paperId = $obj->paperId;

            $assessmentDetailsArray = array();
            $getOnlineAssessment = array();
            $getOnlineAssessmentnew = array();
            for ($i = 0; $i < $totalQuestions; $i++) {

                $questionArray = Yii::app()->db->createCommand("SELECT question_id,question_set_id,question,option1,option2,option3,option4,answer_option,answer,question_marks,nos_code FROM master_generate_questions where paper_id ='" . $paperId . "' AND question_id = '$questionIdArray[$i]'")->queryAll();


                foreach ($questionArray As $questionValue) {
                    $assessmentDetailsArray['question_id'] = $questionValue['question_id'];
                    $assessmentDetailsArray['question_set_id'] = $questionValue['question_set_id'];
//                    $assessmentDetailsArray['question'] = $questionValue['question'];
//                    $assessmentDetailsArray['option1'] = $questionValue['option1'];
//                    $assessmentDetailsArray['option2'] = $questionValue['option2'];
//                    $assessmentDetailsArray['option3'] = $questionValue['option3'];
//                   $assessmentDetailsArray['option4'] = $questionValue['option4'];
//                    $assessmentDetailsArray['answer'] = $questionValue['answer'];
                    $assessmentDetailsArray['answer_option'] = $questionValue['answer_option'];
                    $answered = $radioAnsweredArray[$i];
                    if ($answered == "undefined") {
                        $assessmentDetailsArray['answered'] = "No Answered";
                    } else {
                        $assessmentDetailsArray['answered'] = $answered;
                    }

                    $checked = substr($radioAnsweredArray[$i], -1);
                    if ($checked == "d") {
                        $assessmentDetailsArray['checked'] = "No Checked";
                    } else {
                        $assessmentDetailsArray['checked'] = $checked;
                    }

                    if ($assessmentDetailsArray['answer_option'] == $checked) {
                        $assessmentDetailsArray['question_answered_status'] = "Correct";
                    } else {
                        $assessmentDetailsArray['question_answered_status'] = "Incorrect";
                    }
                    if ($assessmentDetailsArray['question_answered_status'] == "Incorrect") {
                        $assessmentDetailsArray['get_question_marks'] = 0;
                    } else {
                        $assessmentDetailsArray['get_question_marks'] = $questionValue['question_marks'];
                    }
                    $assessmentDetailsArray['question_marks'] = $questionValue['question_marks'];
                    $assessmentDetailsArray['nos_code'] = $questionValue['nos_code'];
                    $getOnlineAssessment[] = $assessmentDetailsArray;
                }
            }
            //$getOnlineAssessment = array();
            // echo "<pre>";
//print_r($getOnlineAssessment);die;
            $assessment_record = json_encode($getOnlineAssessment);

            // $assessment_record = array();
            $newNosArray = array();
            $finalNosArray = array();


            $candidateName = Yii::app()->db->createCommand("SELECT candidate_name FROM essci_candidate_details WHERE candidate_id = '" . $candidateId . "'")->queryAll();
            $candidateName = isset($candidateName[0]['candidate_name']) ? $candidateName[0]['candidate_name'] : '';

            foreach ($getOnlineAssessment As $nosArray) {

                $newNosArray['candidate_id'] = $candidateId;
                $newNosArray['candidate_name'] = $candidateName;
                $newNosArray['nos_code'] = $nosArray['nos_code'];
                $newNosArray['question_marks'] = $nosArray['question_marks'];
                $newNosArray['question_answered_status'] = $nosArray['question_answered_status'];
                $newNosArray['get_question_marks'] = $nosArray['get_question_marks'];


                $finalNosArray[$newNosArray['nos_code']][] = $newNosArray;
            }

            $totalmarks = 0;
            $totalCorrect = 0;
            $totalInCorrect = 0;
            $totalFinalCorrect = 0;
            $totalFinalInCorrect = 0;
            $newOneNos = array();
            $newfinalNos = array();
            foreach ($finalNosArray As $keyValue => $getAssessmentNosSet) {

                $newOneNos['nos_code'] = $keyValue;
                foreach ($getAssessmentNosSet As $key => $value) {

                    $totalmarks += $value['get_question_marks'];
                    $newOneNos['total_theory_marks'] = $totalmarks;
                    $newOneNos['total_practical_marks'] = 0;
                    $newOneNos['total_viva_marks'] = 0;
                    if ($value['question_answered_status'] == "Correct") {
                        $totalCorrect += 1;
                        $newOneNos['total_correct'] = $totalCorrect;
                    } else {
                        $newOneNos['total_correct'] = $totalCorrect;
                    }
                    if ($value['question_answered_status'] == "Incorrect") {

                        $totalInCorrect += 1;
                        $newOneNos['total_incorrect'] = $totalInCorrect;
                    } else {
                        $newOneNos['total_incorrect'] = $totalInCorrect;
                    }
                }
                $newfinalNos[] = $newOneNos;
                $totalFinalCorrect += $totalCorrect;
                $totalFinalInCorrect += $totalInCorrect;
                $totalmarks = 0;
                $totalCorrect = 0;
                $totalInCorrect = 0;
            }


            $assessmment_nos_record = json_encode($newfinalNos);



            //my update code

            $beforenosCodeArray = Yii::app()->db->createCommand("SELECT assessmment_nos_record FROM master_online_assessment_result where candidate_id='" . $candidateId . "'")->queryAll();

            $finalbeforenosrecord = isset($beforenosCodeArray[0]['assessmment_nos_record']) ? $beforenosCodeArray[0]['assessmment_nos_record'] : '';

            $finalRecord = json_decode($finalbeforenosrecord);


            $mynewoldarray = array();
            $myFinalnewoldarray = array();
            foreach ($finalRecord As $obj) {
                $mynewoldarray['nos_code'] = $obj->nos_code;
                $mynewoldarray['total_theory_marks'] = $obj->total_theory_marks;
                $mynewoldarray['total_practical_marks'] = $obj->total_practical_marks;
                $mynewoldarray['total_viva_marks'] = $obj->total_viva_marks;
                $mynewoldarray['total_correct'] = $obj->total_correct;
                $mynewoldarray['total_incorrect'] = $obj->total_incorrect;
                $myFinalnewoldarray[] = $mynewoldarray;
            }

            $myFinalnewoldarrayGroupBy = set_group_by("nos_code", $myFinalnewoldarray);




            $myshuffle = shuffle_assoc($newfinalNos);

            $nosCodeArray = set_group_by("nos_code", $myshuffle);



            foreach ($nosCodeArray as $key => $value) {



                $nosCodeArray[$key]['total_theory_marks'] = $value['total_theory_marks'];
            }


            $saveArray = array_values($nosCodeArray);

            $nosCodeMarkArrayGroupBy = set_group_by("nos_code", $saveArray);


            $completeFinalArray = array();
            $FinalResultArray = array();
            foreach ($myFinalnewoldarrayGroupBy As $key => $value) {


                $completeFinalArray['nos_code'] = $myFinalnewoldarrayGroupBy[$key]['nos_code'];
                $completeFinalArray['total_theory_marks'] = $nosCodeMarkArrayGroupBy[$key]['total_theory_marks'];
                $completeFinalArray['total_practical_marks'] = $myFinalnewoldarrayGroupBy[$key]['total_practical_marks'];
                $completeFinalArray['total_viva_marks'] = $myFinalnewoldarrayGroupBy[$key]['total_viva_marks'];
                $completeFinalArray['total_correct'] = $nosCodeMarkArrayGroupBy[$key]['total_correct'];
                $completeFinalArray['total_incorrect'] = $nosCodeMarkArrayGroupBy[$key]['total_incorrect'];
                $FinalResultArray[] = $completeFinalArray;
            }

            //echo "<pre>";

           //print_r($FinalResultArray);exit;

            $assessmment_update_nos_record = json_encode($FinalResultArray);


            $batchDetails = Yii::app()->db->createCommand("SELECT scheme_type,qualification_pack,qp_code,assessment_date,assessment_date_format,assessor_name,assessingbody_name,scheme_name FROM essci_batch_details where batch_id ='" . $batchId . "'")->queryAll();
            $assessment_date = isset($batchDetails[0]['assessment_date']) ? $batchDetails[0]['assessment_date'] : '';
            $assessment_date_format = isset($batchDetails[0]['assessment_date_format']) ? $batchDetails[0]['assessment_date_format'] : '';

            //echo $assessment_date_format;die;
            $assessor_name = isset($batchDetails[0]['assessor_name']) ? $batchDetails[0]['assessor_name'] : '';
            $assessingbody_name = isset($batchDetails[0]['assessingbody_name']) ? $batchDetails[0]['assessingbody_name'] : '';
            $scheme_type = isset($batchDetails[0]['scheme_type']) ? $batchDetails[0]['scheme_type'] : '';
            $scheme_name = isset($batchDetails[0]['scheme_name']) ? $batchDetails[0]['scheme_name'] : '';

            $paperDetails = Yii::app()->db->createCommand("SELECT paper_jobrole,paper_qpcode,paper_total_nos,paper_total_question,paper_total_marks FROM master_generate_paperset where paper_id ='" . $paperId . "'")->queryAll();
            $paper_jobrole = isset($paperDetails[0]['paper_jobrole']) ? $paperDetails[0]['paper_jobrole'] : '';
            $paper_qpcode = isset($paperDetails[0]['paper_qpcode']) ? $paperDetails[0]['paper_qpcode'] : '';
            $paper_total_nos = isset($paperDetails[0]['paper_total_nos']) ? $paperDetails[0]['paper_total_nos'] : '';
            $paper_total_question = isset($paperDetails[0]['paper_total_question']) ? $paperDetails[0]['paper_total_question'] : '';
            $paper_total_marks = isset($paperDetails[0]['paper_total_marks']) ? $paperDetails[0]['paper_total_marks'] : '';

            $getAssessmentId = "TEMP";

            $createdDate = date('Y-m-d');

			echo 1;
            exit;

            $updateResultData = Yii::app()->db->createCommand("UPDATE master_online_assessment_result SET assessmment_nos_record = '" . $assessmment_update_nos_record . "', assessment_record = '" . $assessment_record . "', paper_id = '" . $paperId . "', job_role = '" . $paper_jobrole . "', qp_code = '" . $paper_qpcode . "', no_of_question = $paper_total_question, not_visited =  $notVisited, not_answered = $notAnswered, answered = $Answered, correct = $totalFinalCorrect, incorrect = $totalFinalInCorrect, total_paper_marks = $paper_total_marks WHERE candidate_id='" . $candidateId . "'")->execute();



            if ($updateResultData) {
                $year = date('Y');

                Yii::app()->db->createCommand("UPDATE essci_candidate_details SET online_theory_assessment_status = 'C' WHERE candidate_id='$candidateId'")->execute();

                echo "1";
            } else {
                echo "Error";
            }
        }
    }
    
    /* old format insert  public function actionSaveonlineassessment(){
        
        if (isset($_GET['onlineAssessment'])) {
            $obj = json_decode($_GET["onlineAssessment"]);
            $questionNo = explode(",", substr_replace($obj->questionNo, "", -1));
            $questionIdArray = explode(",", substr_replace($obj->questionIdArray, "", -1));
            $radioAnsweredArray = explode(",", substr_replace($obj->radioAnsweredArray, "", -1));
            $totalQuestions = $obj->totalQuestions;
            $candidateId = $obj->candidateId;
            $batchId = $obj->batchId;
            $notVisited = $obj->notVisited;
            $notAnswered = $obj->notAnswered;
            $Answered = $obj->Answered;
            $paperId = $obj->paperId;
            
            $assessmentDetailsArray = array();
            $getOnlineAssessment = array();
            $getOnlineAssessmentnew = array();
            for ($i = 0 ; $i<$totalQuestions;$i++){
           
                $questionArray = Yii::app()->db->createCommand("SELECT question_id,question_set_id,question,option1,option2,option3,option4,answer_option,answer,question_marks,nos_code FROM master_generate_questions where paper_id ='".$paperId."' AND question_id = '$questionIdArray[$i]'")->queryAll();
       
                
                foreach ($questionArray As $questionValue){
                    $assessmentDetailsArray['question_id'] = $questionValue['question_id'];
                    $assessmentDetailsArray['question_set_id'] = $questionValue['question_set_id'];
//                    $assessmentDetailsArray['question'] = $questionValue['question'];
//                    $assessmentDetailsArray['option1'] = $questionValue['option1'];
//                    $assessmentDetailsArray['option2'] = $questionValue['option2'];
//                    $assessmentDetailsArray['option3'] = $questionValue['option3'];
//                   $assessmentDetailsArray['option4'] = $questionValue['option4'];
//                    $assessmentDetailsArray['answer'] = $questionValue['answer'];
                    $assessmentDetailsArray['answer_option'] = $questionValue['answer_option'];
                     $answered = $radioAnsweredArray[$i];
                    if($answered == "undefined"){
                        $assessmentDetailsArray['answered'] = "No Answered"; 
                     }else{
                         $assessmentDetailsArray['answered'] = $answered;
                     }
                     
                    $checked = substr($radioAnsweredArray[$i],-1);
                    if($checked == "d"){
                        $assessmentDetailsArray['checked'] = "No Checked"; 
                     }else{
                         $assessmentDetailsArray['checked'] = $checked;
                     }
                    
                    if($assessmentDetailsArray['answer_option'] == $checked){
                        $assessmentDetailsArray['question_answered_status'] = "Correct";
                    }else{
                        $assessmentDetailsArray['question_answered_status'] = "Incorrect";
                    }
                    if($assessmentDetailsArray['question_answered_status'] == "Incorrect"){
                    $assessmentDetailsArray['get_question_marks'] = 0;
                    }else{
                       $assessmentDetailsArray['get_question_marks'] = $questionValue['question_marks']; 
                    }
                    $assessmentDetailsArray['question_marks'] = $questionValue['question_marks']; 
                    $assessmentDetailsArray['nos_code'] = $questionValue['nos_code'];
                    $getOnlineAssessment[]=$assessmentDetailsArray;
                }
                
                
            }
            //$getOnlineAssessment = array();
  //        echo "<pre>";
//print_r($getOnlineAssessment);die;
            $assessment_record = json_encode($getOnlineAssessment);
            
           // $assessment_record = array();
            $newNosArray = array();
            $finalNosArray = array();
            
            
            $candidateName = Yii::app()->db->createCommand("SELECT candidate_name FROM essci_candidate_details WHERE candidate_id = '" . $candidateId . "'")->queryAll();
            $candidateName = isset($candidateName[0]['candidate_name'])?$candidateName[0]['candidate_name']:''; 
            
            foreach ($getOnlineAssessment As $nosArray){
                
                $newNosArray['candidate_id'] = $candidateId;
                $newNosArray['candidate_name'] = $candidateName;
                $newNosArray['nos_code'] = $nosArray['nos_code'];
                $newNosArray['question_marks'] = $nosArray['question_marks'];
                $newNosArray['question_answered_status'] = $nosArray['question_answered_status'];
                 $newNosArray['get_question_marks'] = $nosArray['get_question_marks'];
                
               
                $finalNosArray[$newNosArray['nos_code']][] = $newNosArray;
                
            }
            
            $totalmarks = 0;
            $totalCorrect = 0;
            $totalInCorrect = 0;
            $totalFinalCorrect = 0;
            $totalFinalInCorrect = 0;
            $newOneNos = array();
            $newfinalNos = array();
            foreach ($finalNosArray As $keyValue => $getAssessmentNosSet) {
                
                $newOneNos['nos_code'] = $keyValue;
                foreach ($getAssessmentNosSet As $key => $value) {
                    
                     $totalmarks += $value['get_question_marks'];
                     $newOneNos['total_theory_marks'] = $totalmarks;
                     $newOneNos['total_practical_marks'] = 0;
                     $newOneNos['total_viva_marks'] = 0;
                     if($value['question_answered_status'] == "Correct"){
                        $totalCorrect += 1;
                        $newOneNos['total_correct'] = $totalCorrect;
                     }else{
                         $newOneNos['total_correct'] = $totalCorrect;
                     }
                     if($value['question_answered_status'] == "Incorrect"){
                        
                        $totalInCorrect += 1;
                        $newOneNos['total_incorrect'] = $totalInCorrect;
                     }else{
                         $newOneNos['total_incorrect'] = $totalInCorrect;
                     }
                     
                    
                }
               $newfinalNos[]=$newOneNos;
               $totalFinalCorrect += $totalCorrect;
               $totalFinalInCorrect += $totalInCorrect;
               $totalmarks = 0;
               $totalCorrect = 0;
               $totalInCorrect = 0;
            }
             
            
            $assessmment_nos_record = json_encode($newfinalNos);
                     // echo "<pre>";
           // print_r($newfinalNos); 
            $batchDetails =  Yii::app()->db->createCommand("SELECT scheme_type,qualification_pack,qp_code,assessment_date,assessment_date_format,assessor_name,assessingbody_name,scheme_name FROM essci_batch_details where batch_id ='".$batchId."'")->queryAll();
            $assessment_date = isset($batchDetails[0]['assessment_date'])?$batchDetails[0]['assessment_date']:'';
            $assessment_date_format = isset($batchDetails[0]['assessment_date_format'])?$batchDetails[0]['assessment_date_format']:'';
            
            //echo $assessment_date_format;die;
            $assessor_name = isset($batchDetails[0]['assessor_name'])?$batchDetails[0]['assessor_name']:'';
            $assessingbody_name = isset($batchDetails[0]['assessingbody_name'])?$batchDetails[0]['assessingbody_name']:'';
            $scheme_type = isset($batchDetails[0]['scheme_type'])?$batchDetails[0]['scheme_type']:'';
            $scheme_name = isset($batchDetails[0]['scheme_name'])?$batchDetails[0]['scheme_name']:'';
            
            $paperDetails =  Yii::app()->db->createCommand("SELECT paper_jobrole,paper_qpcode,paper_total_nos,paper_total_question,paper_total_marks FROM master_generate_paperset where paper_id ='".$paperId."'")->queryAll();
            $paper_jobrole = isset($paperDetails[0]['paper_jobrole'])?$paperDetails[0]['paper_jobrole']:'';
            $paper_qpcode = isset($paperDetails[0]['paper_qpcode'])?$paperDetails[0]['paper_qpcode']:'';
            $paper_total_nos = isset($paperDetails[0]['paper_total_nos'])?$paperDetails[0]['paper_total_nos']:'';
            $paper_total_question = isset($paperDetails[0]['paper_total_question'])?$paperDetails[0]['paper_total_question']:'';
            $paper_total_marks = isset($paperDetails[0]['paper_total_marks'])?$paperDetails[0]['paper_total_marks']:'';
        
            $getAssessmentId = "TEMP";

            $createdDate = date('Y-m-d');
            
            $saveInvoice = Yii::app()->db->createCommand("INSERT INTO `master_online_assessment_result` (`assessment_id`, `candidate_id`, `batch_id`, `assessment_date`,`assessment_date_format`, `assessingbody_name` ,`assessor_name`, `paper_id`, `job_role`, `qp_code`, `no_of_question`, `assessment_record`, `assessmment_nos_record`, `not_visited`, `not_answered`, `answered`, `correct`, `incorrect`,`total_paper_marks`,`scheme_name`,`status`,`created_at`) VALUES ('" . $getAssessmentId . "','" . $candidateId . "', '" . $batchId . "','".$assessment_date."','".$assessment_date_format."','".$assessingbody_name."','".$assessor_name."','".$paperId."','".$paper_jobrole."','".$paper_qpcode."',$paper_total_question,'".$assessment_record."','".$assessmment_nos_record."',$notVisited,$notAnswered,$Answered,$totalFinalCorrect,$totalFinalInCorrect,$paper_total_marks,'".$scheme_name."','A','".$createdDate."')")->execute();
            $lastAssessmentId = Yii::app()->db->getLastInsertId();
            
            if ($saveInvoice) {
                $year = date('Y');
                $updateInvoiceId = "Assessment_" . $year . "_" . $lastAssessmentId;
                Yii::app()->db->createCommand("UPDATE master_online_assessment_result SET assessment_id = '" . $updateInvoiceId . "' WHERE id='" . $lastAssessmentId . "'")->execute();
                Yii::app()->db->createCommand("UPDATE essci_candidate_details SET online_theory_assessment_status = 'C' WHERE candidate_id='$candidateId'")->execute();

                echo "1";
            } else {
                echo "Error";
            }
            
            
            
        }
        
    }
     
     */
    public function actionSaveonlinevivaassessment(){
        
        if (isset($_GET['onlineVivaAssessment'])) {
            $obj = json_decode($_GET["onlineVivaAssessment"]);
            
           $candidate_id =  $obj->candidate_id;
           $nos_code =  $obj->nos_code;
           $viva_marks =  $obj->viva_marks;
           
           
           
           $resultNosArray = Yii::app()->db->createCommand("SELECT assessmment_nos_record FROM master_online_assessment_result WHERE candidate_id = '" . $candidate_id . "'")->queryAll();
          $resultNosArray = $resultNosArray[0]['assessmment_nos_record'];
          
          
          
          $finalNosArray = json_decode($resultNosArray, true);
          
         // echo "<pre>";
         // print_r($finalNosArray);
         
          $nosCodeArray = set_group_by("nos_code", $finalNosArray);
          
          
          
          foreach ($nosCodeArray as $key => $value) {
              
              
              $nosCodeArray[$nos_code]['total_viva_marks'] = $viva_marks;
              
          }
          
          ///echo '<pre>';
          //print_r($nosCodeArray);
          
          $saveArray = array_values($nosCodeArray);
          
          
          $assessmment_update_nos_record = json_encode($saveArray);
           
           
           $updateDone = Yii::app()->db->createCommand("UPDATE master_online_assessment_result SET assessmment_nos_record = '" . $assessmment_update_nos_record . "' WHERE candidate_id='" . $candidate_id . "'")->execute();
                
           if($updateDone){
               echo "1";
           }else{
               echo "0";
           }
           
           
           
            
            
        }
        
        
    }
    
    public function actionSaveonlinepracticalassessment(){
        
        if (isset($_GET['onlinePracticalAssessment'])) {
            $obj = json_decode($_GET["onlinePracticalAssessment"]);
            
           $candidate_id =  $obj->candidate_id;
           $nos_code =  $obj->nos_code;
           $practical_marks =  $obj->practical_marks;
           
           
           
           $resultNosArray = Yii::app()->db->createCommand("SELECT assessmment_nos_record FROM master_online_assessment_result WHERE candidate_id = '" . $candidate_id . "'")->queryAll();
          $resultNosArray = $resultNosArray[0]['assessmment_nos_record'];
          
          
          
          $finalNosArray = json_decode($resultNosArray, true);
          
         // echo "<pre>";
         // print_r($finalNosArray);
         
          $nosCodeArray = set_group_by("nos_code", $finalNosArray);
          
          
          
          foreach ($nosCodeArray as $key => $value) {
              
              
              $nosCodeArray[$nos_code]['total_practical_marks'] = $practical_marks;
              
          }
          
          ///echo '<pre>';
          //print_r($nosCodeArray);
          
          $saveArray = array_values($nosCodeArray);
          
          
          $assessmment_update_nos_record = json_encode($saveArray);
           
           
           $updateDone = Yii::app()->db->createCommand("UPDATE master_online_assessment_result SET assessmment_nos_record = '" . $assessmment_update_nos_record . "' WHERE candidate_id='" . $candidate_id . "'")->execute();
                
           if($updateDone){
               echo "1";
           }else{
               echo "0";
           }
           
           
           
            
            
        }
        
        
    }
    
   /* public function actionSaveonlinepracticalassessment(){
        
        if (isset($_GET['onlinePracticalAssessment'])) {
            $obj = json_decode($_GET["onlinePracticalAssessment"]);
            
           $candidate_id =  $obj->candidate_id;
           $nos_code =  $obj->nos_code;
           $practical_marks =  $obj->practical_marks;
           
           
           
           $resultNosArray = Yii::app()->db->createCommand("SELECT assessmment_nos_record FROM master_online_assessment_result WHERE candidate_id = '" . $candidate_id . "'")->queryAll();
          $resultNosArray = $resultNosArray[0]['assessmment_nos_record'];
          
          
          
          $finalNosArray = json_decode($resultNosArray, true);
          
         // echo "<pre>";
         // print_r($finalNosArray);
         
          $nosCodeArray = set_group_by("nos_code", $finalNosArray);
          
          
          
          foreach ($nosCodeArray as $key => $value) {
              
              
              $nosCodeArray[$nos_code]['total_practical_marks'] = $practical_marks;
              
          }
          
          ///echo '<pre>';
          //print_r($nosCodeArray);
          
          $saveArray = array_values($nosCodeArray);
          
          
          $assessmment_update_nos_record = json_encode($saveArray);
           
           
           $updateDone = Yii::app()->db->createCommand("UPDATE master_online_assessment_result SET assessmment_nos_record = '" . $assessmment_update_nos_record . "' WHERE candidate_id='" . $candidate_id . "'")->execute();
                
           if($updateDone){
               echo "1";
           }else{
               echo "0";
           }
           
           
           
            
            
        }
        
        
    }*/



    /**
     * Performs the AJAX validation.
     * @param Users $model the model to be validated
     */
    protected function performAjaxValidation($model) {
        if (isset($_POST['ajax']) && $_POST['ajax'] === 'users-form') {
            echo CActiveForm::validate($model);
            Yii::app()->end();
        }
    }

}


function group_by($key, $data) {
    $result = array();

    foreach($data as $val) {
        if(array_key_exists($key, $val)){
            $result[$val[$key]][] = $val;
        }else{
            $result[""] = $val;
        }
    }

    return $result;
}
function set_group_by($key, $data) {
    $result = array();

    foreach($data as $val) {
        if(array_key_exists($key, $val)){
            $result[$val[$key]] = $val;
        }else{
            $result[""] = $val;
        }
    }

    return $result;
}

function shuffle_assoc($list) {
    if (!is_array($list))
        return $list;

    $keys = array_keys($list);
    shuffle($keys);
    $random = array();
    foreach ($keys as $key) {
        $random[$key] = $list[$key];
    }
    return $random;
}

?>
